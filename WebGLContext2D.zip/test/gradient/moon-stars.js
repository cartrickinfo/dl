const moonGrad = ctx.createRadialGradient(350, 280, 5, 350, 280, 35);
moonGrad.addColorStop(0, '#f39c12');
moonGrad.addColorStop(0.4, '#e67e22');
moonGrad.addColorStop(1, '#d35400');

ctx.beginPath();
ctx.arc(350, 280, 35, 0, Math.PI * 2);
ctx.fillStyle = moonGrad;
ctx.fill();

// --- Small stars around the moon (simpler) ---
const starPositions = [
    [310, 250], [390, 240], [420, 270], [400, 320], [300, 310], [280, 280]
];

starPositions.forEach(([x, y]) => {
    const smallStarGrad = ctx.createRadialGradient(x, y, 0, x, y, 8);
    smallStarGrad.addColorStop(0, '#ffffff');
    smallStarGrad.addColorStop(0.7, '#f1c40f');
    smallStarGrad.addColorStop(1, '#e67e22');

    // Simple star with intersecting lines
    ctx.beginPath();
    ctx.moveTo(x - 8, y);
    ctx.lineTo(x + 8, y);
    ctx.moveTo(x, y - 8);
    ctx.lineTo(x, y + 8);
    ctx.moveTo(x - 6, y - 6);
    ctx.lineTo(x + 6, y + 6);
    ctx.moveTo(x - 6, y + 6);
    ctx.lineTo(x + 6, y - 6);

    ctx.lineWidth = 3;
    ctx.strokeStyle = smallStarGrad;
    ctx.stroke();

    // Star center
    ctx.beginPath();
    ctx.arc(x, y, 2, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.fill();
});