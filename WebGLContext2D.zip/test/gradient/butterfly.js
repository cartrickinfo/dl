const butterflyGrad = ctx.createLinearGradient(100, 380, 200, 450);
butterflyGrad.addColorStop(0, '#ff6b6b');
butterflyGrad.addColorStop(0.3, '#4ecdc4');
butterflyGrad.addColorStop(0.7, '#45b7d1');
butterflyGrad.addColorStop(1, '#96ceb4');

// Right wing
ctx.beginPath();
ctx.moveTo(150, 410);
ctx.bezierCurveTo(120, 380, 100, 400, 110, 430);
ctx.bezierCurveTo(90, 450, 120, 470, 150, 450);
ctx.closePath();

ctx.fillStyle = butterflyGrad;
ctx.fill();

// Left wing
ctx.beginPath();
ctx.moveTo(150, 410);
ctx.bezierCurveTo(180, 380, 200, 400, 190, 430);
ctx.bezierCurveTo(210, 450, 180, 470, 150, 450);
ctx.closePath();

ctx.fillStyle = butterflyGrad;
ctx.fill();

// Butterfly body
ctx.beginPath();
ctx.ellipse(150, 430, 3, 25, 0, 0, Math.PI * 2);
ctx.fillStyle = '#2c3e50';
ctx.fill();