const rainbowColors = [
    '#e74c3c', '#f39c12', '#f1c40f', '#2ecc71', '#3498db', '#9b59b6'
];

for (let i = 0; i < rainbowColors.length; i++) {
    const radius = 140 - (i * 15);

    const rainbowGrad = ctx.createLinearGradient(150, 450, 450, 450);
    rainbowGrad.addColorStop(0, rainbowColors[i]);
    rainbowGrad.addColorStop(0.5, rainbowColors[i]);
    rainbowGrad.addColorStop(1, 'rgba(255,255,255,0.3)');

    ctx.beginPath();
    ctx.arc(300, 500, radius, Math.PI, 0);
    ctx.lineWidth = 12;
    ctx.strokeStyle = rainbowGrad;
    ctx.stroke();
}