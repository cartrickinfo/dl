const centerX = 100;
const centerY = 100;

const sunflowerStrokeGrad = ctx.createRadialGradient(centerX, centerY, 10, centerX, centerY, 70);
sunflowerStrokeGrad.addColorStop(0, '#f39c12');
sunflowerStrokeGrad.addColorStop(0.5, '#e67e22');
sunflowerStrokeGrad.addColorStop(1, '#d35400');

for (let i = 0; i < 12; i++) {
    const angle = (i * Math.PI * 2) / 12;
    const x1 = centerX + Math.cos(angle) * 25;
    const y1 = centerY + Math.sin(angle) * 25;
    const x2 = centerX + Math.cos(angle) * 55;
    const y2 = centerY + Math.sin(angle) * 55;

    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineWidth = 8;
    ctx.strokeStyle = sunflowerStrokeGrad;
    ctx.stroke();
}

const centerGrad = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, 20);
centerGrad.addColorStop(0, '#8b4513');
centerGrad.addColorStop(0.6, '#654321');
centerGrad.addColorStop(1, '#2f1b14');

ctx.beginPath();
ctx.arc(centerX, centerY, 20, 0, Math.PI * 2);
ctx.fillStyle = centerGrad;
ctx.fill();