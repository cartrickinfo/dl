const starGrad = ctx.createConicGradient(0, 400, 120);
starGrad.addColorStop(0, '#ff4757');
starGrad.addColorStop(0.2, '#ffa502');
starGrad.addColorStop(0.4, '#2ed573');
starGrad.addColorStop(0.6, '#1e90ff');
starGrad.addColorStop(0.8, '#8e44ad');
starGrad.addColorStop(1, '#ff4757');

ctx.beginPath();
const centerX = 400, centerY = 120;
const outerRadius = 50, innerRadius = 25;

for (let i = 0; i < 16; i++) {
    const angle = (i * Math.PI) / 8;
    const radius = i % 2 === 0 ? outerRadius : innerRadius;
    const x = centerX + Math.cos(angle - Math.PI/2) * radius;
    const y = centerY + Math.sin(angle - Math.PI/2) * radius;

    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
}
ctx.closePath();

ctx.fillStyle = starGrad;
ctx.fill();