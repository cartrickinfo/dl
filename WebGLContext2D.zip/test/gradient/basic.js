// Linear Gradient
const linearGrad = ctx.createLinearGradient(0, 0, 200, 0);
linearGrad.addColorStop(0, '#ff0000');
linearGrad.addColorStop(0.5, '#00ff00');
linearGrad.addColorStop(1, '#0000ff');

ctx.fillStyle = linearGrad;
ctx.fillRect(50, 50, 200, 100);

// Radial Gradient
const radialGrad = ctx.createRadialGradient(400, 100, 0, 400, 100, 80);
radialGrad.addColorStop(0, '#ffff00');
radialGrad.addColorStop(0.7, '#ff8800');
radialGrad.addColorStop(1, '#ff0000');

ctx.fillStyle = radialGrad;
ctx.fillRect(320, 20, 160, 160);

// Conic Gradient
const conicGrad = ctx.createConicGradient(0, 150, 300);
conicGrad.addColorStop(0, '#ff0000');
conicGrad.addColorStop(0.25, '#ffff00');
conicGrad.addColorStop(0.5, '#00ff00');
conicGrad.addColorStop(0.75, '#00ffff');
conicGrad.addColorStop(1, '#ff0000');

ctx.fillStyle = conicGrad;
ctx.fillRect(70, 220, 160, 160);

// Path with Gradient
const pathGrad = ctx.createLinearGradient(300, 250, 450, 350);
pathGrad.addColorStop(0, '#ff0808');
pathGrad.addColorStop(1, '#4a00e0');

ctx.beginPath();
ctx.moveTo(350, 250);
ctx.lineTo(450, 280);
ctx.lineTo(420, 350);
ctx.lineTo(320, 330);
ctx.closePath();

ctx.fillStyle = pathGrad;
ctx.fill();

// Stroke with Gradient
const strokeGrad = ctx.createRadialGradient(550, 300, 5, 550, 300, 50);
strokeGrad.addColorStop(0, '#00ffec');
strokeGrad.addColorStop(1, '#00a6ff');

ctx.beginPath();
ctx.arc(550, 300, 60, 0, Math.PI * 2);
ctx.lineWidth = 10;
ctx.strokeStyle = strokeGrad;
ctx.stroke();