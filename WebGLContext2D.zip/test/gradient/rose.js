const roseGrad = ctx.createRadialGradient(150, 120, 10, 150, 120, 60);
roseGrad.addColorStop(0, '#ff69b4');
roseGrad.addColorStop(0.3, '#ff1493');
roseGrad.addColorStop(0.7, '#dc143c');
roseGrad.addColorStop(1, '#8b0000');

// Rose branches
for (let i = 0; i < 8; i++) {
    const angle = (i * Math.PI * 2) / 8;
    const x = 150 + Math.cos(angle) * 25;
    const y = 120 + Math.sin(angle) * 25;

    ctx.beginPath();
    ctx.arc(x, y, 20, 0, Math.PI * 2);
    ctx.fillStyle = roseGrad;
    ctx.fill();
}

// Flower center
ctx.beginPath();
ctx.arc(150, 120, 15, 0, Math.PI * 2);
ctx.fillStyle = '#ffd700';
ctx.fill();
