const waveGrad1 = ctx.createLinearGradient(50, 250, 250, 320);
waveGrad1.addColorStop(0, '#74b9ff');
waveGrad1.addColorStop(0.3, '#0984e3');
waveGrad1.addColorStop(0.6, '#002bff');
waveGrad1.addColorStop(1, '#0005ff');

ctx.beginPath();
ctx.moveTo(50, 300);

// sinusoidal waves
for (let x = 50; x <= 250; x += 5) {
    const y1 = 280 + Math.sin((x - 50) * 0.05) * 20;
    const y2 = 300 + Math.cos((x - 50) * 0.03) * 15;
    const y = (y1 + y2) / 2;
    ctx.lineTo(x, y);
}

ctx.lineTo(250, 350);
ctx.lineTo(50, 350);
ctx.closePath();

ctx.fillStyle = waveGrad1;
ctx.fill();