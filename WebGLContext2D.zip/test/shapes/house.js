// Draw a house!
ctx.beginPath();
ctx.moveTo(100, 200);
ctx.lineTo(200, 200);
ctx.lineTo(200, 100);
ctx.lineTo(150, 50);
ctx.lineTo(100, 100);
ctx.closePath();
ctx.fillStyle = '#ffcc00';
ctx.fill();
ctx.strokeStyle = '#000';
ctx.stroke();