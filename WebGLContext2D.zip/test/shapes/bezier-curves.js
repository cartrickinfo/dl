// Quadratic curve
ctx.beginPath();
ctx.moveTo(50, 350);
ctx.quadraticCurveTo(150, 280, 250, 350);
ctx.strokeStyle = '#3498DB';
ctx.lineWidth = 4;
ctx.stroke();

// Cubic bezier curve
ctx.beginPath();
ctx.moveTo(300, 350);
ctx.bezierCurveTo(350, 280, 450, 420, 500, 350);
ctx.strokeStyle = '#E67E22';
ctx.lineWidth = 4;
ctx.stroke();

// Closed curve
ctx.beginPath();
ctx.moveTo(550, 320);
ctx.quadraticCurveTo(600, 280, 650, 320);
ctx.quadraticCurveTo(680, 360, 650, 400);
ctx.quadraticCurveTo(600, 420, 550, 400);
ctx.quadraticCurveTo(520, 360, 550, 320);
ctx.fillStyle = '#1ABC9C';
ctx.fill();