// Red rectangle
ctx.fillStyle = '#FF0000';
ctx.fillRect(50, 50, 100, 80);

// Semi-transparent blue rectangle
ctx.globalAlpha = 0.7;
ctx.fillStyle = '#0000FF';
ctx.fillRect(80, 80, 100, 80);

// Restore alpha
ctx.globalAlpha = 1.0;

// Green rectangle with stroke
ctx.strokeStyle = '#00AA00';
ctx.lineWidth = 3;
ctx.strokeRect(200, 50, 120, 100);
ctx.fillStyle = '#90EE90';
ctx.fillRect(200, 50, 120, 100);