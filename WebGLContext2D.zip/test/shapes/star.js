const centerX = 550;
const centerY = 220;
const outerRadius = 60;
const innerRadius = 25;
const points = 5;

ctx.beginPath();
for (let i = 0; i < points * 2; i++) {
    const angle = (i * Math.PI) / points;
    const radius = i % 2 === 0 ? outerRadius : innerRadius;
    const x = centerX + radius * Math.cos(angle - Math.PI / 2);
    const y = centerY + radius * Math.sin(angle - Math.PI / 2);

    if (i === 0) {
        ctx.moveTo(x, y);
    } else {
        ctx.lineTo(x, y);
    }
}
ctx.closePath();
ctx.fillStyle = '#E74C3C';
ctx.fill();
ctx.strokeStyle = '#C0392B';
ctx.lineWidth = 2;
ctx.stroke();