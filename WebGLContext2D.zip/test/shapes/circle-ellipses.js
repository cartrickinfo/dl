// Full circle
ctx.beginPath();
ctx.arc(400, 100, 50, 0, 2 * Math.PI);
ctx.fillStyle = '#FF6B6B';
ctx.fill();

// Semi-circle
ctx.beginPath();
ctx.arc(500, 100, 40, 0, Math.PI, false);
ctx.fillStyle = '#4ECDC4';
ctx.fill();

// Ellipse
ctx.beginPath();
ctx.ellipse(600, 100, 60, 30, Math.PI / 4, 0, 2 * Math.PI);
ctx.fillStyle = '#45B7D1';
ctx.fill();