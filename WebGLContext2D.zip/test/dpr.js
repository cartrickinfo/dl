function setupCanvas (devicePixelRatio = null) {
    const displayWidth = canvas.clientWidth;
    const displayHeight = canvas.clientHeight;

    canvas.width = displayWidth * devicePixelRatio;
    canvas.height = displayHeight * devicePixelRatio;

    canvas.style.width = displayWidth + 'px';
    canvas.style.height = displayHeight + 'px';

    ctx.scale(devicePixelRatio, devicePixelRatio);

    return {devicePixelRatio, displayWidth, displayHeight};
}

const customDPR = 2;
setupCanvas(customDPR);

ctx.fillStyle = '#e94560';
ctx.fillRect(10, 10, 100, 100);

ctx.fillStyle = '#0f3460';
ctx.fillRect(120, 10, 100, 100);

ctx.fillStyle = '#16c79a';
ctx.fillRect(10, 120, 100, 100);

ctx.fillStyle = '#f9a826';
ctx.fillRect(120, 120, 100, 100);