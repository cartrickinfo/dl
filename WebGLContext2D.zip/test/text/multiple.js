ctx.fillStyle = '#e94560';
ctx.font = '30px Arial';
ctx.fillText('Hello WebGLContext2D!', 20, 50);

ctx.fillStyle = '#0f3460';
ctx.font = '20px sans-serif';
ctx.fillText('Text rendering test', 20, 100);

ctx.fillStyle = '#16c79a';
ctx.font = '16px monospace';
ctx.fillText('abcdefghijklmnopqrstuvwxyz', 20, 150);

ctx.fillStyle = '#f9a826';
ctx.font = '24px serif';
ctx.fillText('1234567890', 20, 200);

ctx.fillStyle = '#533483';
ctx.font = '18px Arial';
ctx.textAlign = 'center';
ctx.fillText('Center aligned text', 200, 250);