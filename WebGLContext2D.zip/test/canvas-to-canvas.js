const tempCanvas = document.createElement('canvas');
tempCanvas.width = tempCanvas.height = 100;
const tempCtx = tempCanvas.getContext('2d');
tempCtx.fillStyle = 'red';
tempCtx.fillRect(0, 0, 100, 100);

ctx.drawImage(tempCanvas, 100, 50);
console.log('✅ Canvas-to-canvas test');
