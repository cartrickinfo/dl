const rapidImg = new Image();
rapidImg.onload = () => {
    const start = performance.now();

    for (let i = 0; i < 10; i++) {
        ctx.drawImage(rapidImg, 10 + i * 30, 50, 20, 20);
    }

    const end = performance.now();
    console.log(`✅ Rapid draw test: ${end - start}ms`);
};
rapidImg.src = './assets/imagine_ai_2.png';