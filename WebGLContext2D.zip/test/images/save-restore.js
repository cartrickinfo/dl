ctx.fillStyle = 'red'; // #ff0000
ctx.globalAlpha = 0.5;
ctx.save();

ctx.fillStyle = 'blue';
ctx.globalAlpha = 1.0;

const img1 = new Image();
img1.onload = () => {
    ctx.drawImage(img1, 50, 50, 100, 100);

    const img2 = new Image();
    img2.onload = () => {
        ctx.drawImage(img2, 200, 50, 100, 100);

        ctx.restore();

        console.log(ctx.fillStyle);    // 'red' OR '#ff0000' (restored)
        console.log(ctx.globalAlpha);  // 0.5 (restored)
    };
    img2.src = './assets/imagine_ai_2.png';
};
img1.src = './assets/imagine_ai_1.png';