// Basic image drawing
const basicImg = new Image();
basicImg.onload = () => {
    // drawImage(image, dx, dy)
    ctx.drawImage(basicImg, 50, 180);
};
basicImg.src = './assets/imagine_ai_3.png';

// Scaled image
const scaledImg = new Image();
scaledImg.onload = () => {
    // drawImage(image, dx, dy, dw, dh)
    ctx.drawImage(scaledImg, 50, 50, 100, 100);
};
scaledImg.src = './assets/imagine_ai_2.png';

// Cropped and scaled
const CroppedImg = new Image();
CroppedImg.onload = () => {
    // drawImage(image, sx, sy, sw, sh, dx, dy, dw, dh)
    ctx.drawImage(CroppedImg,
        450, 300,
        200, 200,
        180, 50,
        100, 100
    );
};
CroppedImg.src = './assets/imagine_ai_1.png';

