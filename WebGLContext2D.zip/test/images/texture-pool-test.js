// Basic image drawing
const basicImg = new Image();
basicImg.onload = () => {
    // drawImage(image, dx, dy)
    ctx.drawImage(basicImg, 10, 10);
};
basicImg.src = './assets/imagine_ai_3.png';

if (ctx.gl) {
    let textureCount = 0;
    const originalCreateTexture = ctx.gl.createTexture;
    ctx.gl.createTexture = function () {
        textureCount++;
        console.log('Textures created:', textureCount);
        return originalCreateTexture.call(this);
    };
}