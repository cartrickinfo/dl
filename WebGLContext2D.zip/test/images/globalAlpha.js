const alphaImg = new Image();
alphaImg.onload = () => {
    ctx.globalAlpha = 0.5;
    ctx.drawImage(alphaImg, 400, 180, 100, 100);
    ctx.globalAlpha = 1.0;
};
alphaImg.src = './assets/imagine_ai_3.png';