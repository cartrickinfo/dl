let imageCount = 0;

function stressTest () {
    if (imageCount++ > 50) {
        console.log('✅ Memory stress test completed');
        return;
    }

    const img = new Image();
    img.onload = () => {
        ctx.drawImage(img, Math.random() * width, Math.random() * height, 50, 50);
        requestAnimationFrame(stressTest);
    };
    img.src = './assets/imagine_ai_' + ((imageCount % 3) + 1) + '.png';
}

stressTest();