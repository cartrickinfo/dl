const transformImg = new Image();
transformImg.onload = () => {
    ctx.save();
    ctx.translate(100, 100);
    ctx.rotate(Math.PI / 4); // 45 degrees
    ctx.scale(0.5, 0.5);
    ctx.drawImage(transformImg, -50, -50, 100, 100);
    ctx.restore();
    console.log('✅ Transform + image test');
};
transformImg.src = './assets/imagine_ai_2.png';