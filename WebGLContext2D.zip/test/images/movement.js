try {
    // Array of moving images
    const movingImages = [];

    // Moving image class
    class MovingImage {
        constructor (src, x, y, vx, vy, size = 50) {
            this.image = new Image();
            this.x = x;
            this.y = y;
            this.vx = vx; // Horizontal speed
            this.vy = vy; // Vertical speed
            this.size = size;
            this.loaded = false;

            this.image.onload = () => {
                this.loaded = true;
            };
            this.image.src = src;
        }

        update () {
            this.x += this.vx;
            this.y += this.vy;

            // Bounce off walls
            if (this.x <= 0 || this.x >= canvas.width - this.size) {
                this.vx = -this.vx;
                this.x = Math.max(0, Math.min(canvas.width - this.size, this.x));
            }

            if (this.y <= 0 || this.y >= canvas.height - this.size) {
                this.vy = -this.vy;
                this.y = Math.max(0, Math.min(canvas.height - this.size, this.y));
            }
        }

        draw (ctx) {
            if (this.loaded) {
                ctx.drawImage(this.image, this.x, this.y, this.size, this.size);
            }
        }
    }

    // Create moving images
    for (let i = 0; i < 10; i++) {
        const x = Math.random() * (canvas.width - 50);
        const y = Math.random() * (canvas.height - 50);
        const vx = (Math.random() - 0.5) * 6; // Speed between -3 and 3
        const vy = (Math.random() - 0.5) * 6;

        // Use different images (or the same image)
        const imageSrc = `./assets/character.png`;

        movingImages.push(new MovingImage(imageSrc, x, y, vx, vy));
    }

    // FPS variables
    let lastTime = 0;
    let frameCount = 0;
    let fps = 0;

    // Animation loop
    function animate (currentTime) {
        // Calculate FPS
        frameCount++;
        if (currentTime - lastTime >= 1000) {
            fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
            frameCount = 0;
            lastTime = currentTime;
        }

        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // Draw background
        ctx.fillStyle = 'rgba(50, 50, 50, 0.1)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Update and draw images
        movingImages.forEach(img => {
            img.update();
            img.draw(ctx);
        });
        console.log(fps)
        requestAnimationFrame(animate);
    }

    // Start animation
    requestAnimationFrame(animate);
} catch (e) {
    console.log(e)
}