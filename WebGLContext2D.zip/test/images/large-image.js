const largeImg = new Image();
largeImg.onload = () => {
    console.log('Image size:', largeImg.width, 'x', largeImg.height);
    if (largeImg.width > 2000 || largeImg.height > 2000) {
        console.log('✅ Large image handling test');
    }
    ctx.drawImage(largeImg, 50, 50, 350, 350);
};
largeImg.src = './assets/large_image.jpg';