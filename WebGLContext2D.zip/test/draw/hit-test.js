ctx.beginPath();
ctx.arc(150, 150, 50, 0, Math.PI * 2);
ctx.fillStyle = '#4b4b4b';
ctx.fill();
console.log('Point inside:', ctx.isPointInPath(150, 150)); // true