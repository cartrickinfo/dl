ctx.beginPath();
ctx.roundRect(50, 50, 100, 80, [10, 20, 30, 40]);
ctx.fill();