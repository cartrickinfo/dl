// Clear canvas
ctx.clearRect(0, 0, canvas.width, canvas.height);

// Create background
ctx.fillStyle = '#1e293b';
ctx.fillRect(0, 0, canvas.width, canvas.height);

// First clip (outer circle)
ctx.save();
ctx.beginPath();
ctx.arc(200, 150, 140, 0, Math.PI * 2);
ctx.clip();

// Draw background for first clip
ctx.fillStyle = '#3b82f6';
ctx.fillRect(0, 0, canvas.width, canvas.height);

// Second clip (inner rectangle)
ctx.save();
ctx.beginPath();
ctx.rect(120, 70, 160, 160);
ctx.clip();

// Draw content for second clip
ctx.fillStyle = '#fbbf24';
for (let i = 0; i < 10; i++) {
    ctx.fillRect(120 + i * 16, 70, 8, 160);
}

ctx.restore(); // Restore second clip

// Draw content between clips
ctx.fillStyle = '#4b4b4b';
for (let i = 0; i < 20; i++) {
    ctx.beginPath();
    ctx.arc(
        200 + Math.cos(i * Math.PI / 10) * 100,
        150 + Math.sin(i * Math.PI / 10) * 100,
        8, 0, Math.PI * 2
    );
    ctx.fill();
}

ctx.restore(); // Restore first clip