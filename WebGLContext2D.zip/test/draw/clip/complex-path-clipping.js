// Clear canvas
ctx.clearRect(0, 0, canvas.width, canvas.height);

// Create background
ctx.fillStyle = '#0f172a';
ctx.fillRect(0, 0, canvas.width, canvas.height);

// Create complex clipping path (star shape)
ctx.beginPath();
const centerX = 200;
const centerY = 150;
const outerRadius = 120;
const innerRadius = 60;
const points = 8;

for (let i = 0; i < points * 2; i++) {
    const angle = (i * Math.PI) / points;
    const radius = i % 2 === 0 ? outerRadius : innerRadius;
    const x = centerX + Math.cos(angle) * radius;
    const y = centerY + Math.sin(angle) * radius;

    if (i === 0) {
        ctx.moveTo(x, y);
    } else {
        ctx.lineTo(x, y);
    }
}
ctx.closePath();
ctx.clip();

// Draw content inside star
const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
gradient.addColorStop(0, '#3b82f6');
gradient.addColorStop(0.5, '#8b5cf6');
gradient.addColorStop(1, '#ec4899');

ctx.fillStyle = gradient;
ctx.fillRect(0, 0, canvas.width, canvas.height);

// Add some decorative elements
ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
for (let i = 0; i < 30; i++) {
    ctx.save();
    ctx.translate(
        Math.random() * canvas.width,
        Math.random() * canvas.height
    );
    ctx.rotate(Math.random() * Math.PI * 2);
    ctx.fillRect(-20, -2, 40, 4);
    ctx.restore();
}