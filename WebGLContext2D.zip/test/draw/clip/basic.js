// Clear canvas
ctx.clearRect(0, 0, canvas.width, canvas.height);

// Create gradient background
for (let i = 0; i < 10; i++) {
    for (let j = 0; j < 10; j++) {
        ctx.fillStyle = `hsl(${i * 36}, 70%, ${50 + j * 5}%)`;
        ctx.fillRect(i * 40, j * 30, 40, 30);
    }
}

// Apply rectangular clip
ctx.beginPath();
ctx.rect(100, 50, 200, 200);
ctx.clip();

// Draw content that will be clipped
ctx.fillStyle = '#ffffff';
for (let i = 0; i < 20; i++) {
    ctx.save();
    ctx.translate(200, 150);
    ctx.rotate(i * Math.PI / 10);
    ctx.fillRect(-50, -5, 100, 10);
    ctx.restore();
}