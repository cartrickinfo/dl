// Clear canvas
ctx.clearRect(0, 0, canvas.width, canvas.height);

// Create background pattern
ctx.fillStyle = '#1e293b';
ctx.fillRect(0, 0, canvas.width, canvas.height);

for (let i = 0; i < 50; i++) {
    ctx.fillStyle = `hsl(${i * 7.2}, 60%, 45%)`;
    ctx.beginPath();
    ctx.arc(
        Math.random() * canvas.width,
        Math.random() * canvas.height,
        Math.random() * 30 + 5,
        0, Math.PI * 2
    );
    ctx.fill();
}

// Apply circular clip
ctx.beginPath();
ctx.arc(200, 150, 100, 0, Math.PI * 2);
ctx.clip();

// Draw content inside circle
ctx.fillStyle = '#fbbf24';
for (let i = 0; i < 100; i++) {
    ctx.fillRect(
        Math.random() * canvas.width,
        Math.random() * canvas.height,
        4, 4
    );
}