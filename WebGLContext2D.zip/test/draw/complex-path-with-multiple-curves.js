ctx.strokeStyle = 'black';
ctx.fillStyle = 'red';
ctx.lineWidth = 2;

ctx.beginPath();
ctx.moveTo(50, 400);

// Straight line
ctx.lineTo(100, 350);

// Quadratic curve
ctx.quadraticCurveTo(150, 300, 200, 350);

// Bezier curve
ctx.bezierCurveTo(250, 400, 300, 320, 350, 380);

// Arc
ctx.arcTo(400, 350, 380, 420, 30);

// Close path
ctx.lineTo(50, 450);
ctx.closePath();

ctx.fill();
ctx.stroke();

// Expectation: Complex red filled shape with dark border including straight lines and various curves
