ctx.globalAlpha = 0.7;

// Blue circle
ctx.fillStyle = 'blue';
ctx.beginPath();
ctx.arc(150, 100, 50, 0, Math.PI * 2);
ctx.fill();

// Red circle on it
ctx.fillStyle = 'red';
ctx.beginPath();
ctx.arc(180, 120, 50, 0, Math.PI * 2);
ctx.fill();

// Green rounded rectangle
ctx.fillStyle = 'green';
ctx.beginPath();
ctx.roundRect(120, 150, 100, 40, 20);
ctx.fill();

ctx.globalAlpha = 1.0;

// Expectation: Three overlapping translucent shapes that create mixed colors at the intersection points.