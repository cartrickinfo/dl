// Larger background
ctx.fillStyle = '#34495E';
ctx.fillRect(80, 90, 120, 120);

// Draw a pattern
ctx.fillStyle = '#E74C3C';
ctx.fillRect(220, 100, 100, 100);

ctx.fillStyle = '#F1C40F';
ctx.fillRect(350, 110, 80, 80);

// Add a small circle in the cleared area
ctx.beginPath();
ctx.arc(canvas.width / 2, canvas.height / 2, 8, 0, 2 * Math.PI);
ctx.fillStyle = '#2ECC71';
ctx.fill();

// Now clear the squares
setTimeout(() => {
    ctx.clearRect(80, 90, 380, 150);
}, 1000);