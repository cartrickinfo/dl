ctx.strokeStyle = 'purple';
ctx.lineWidth = 4;

ctx.beginPath();
ctx.moveTo(400, 300);
ctx.lineTo(450, 300);
ctx.arcTo(500, 300, 500, 350, 25); // Round corner
ctx.lineTo(500, 400);
ctx.arcTo(500, 450, 450, 450, 25); // Round corner
ctx.lineTo(400, 450);
ctx.arcTo(350, 450, 350, 400, 25); // Round corner
ctx.lineTo(350, 350);
ctx.arcTo(350, 300, 400, 300, 25); // Round corner
ctx.closePath();
ctx.stroke();

// Expectation: Purple rectangle with four perfectly rounded corners by arcTo