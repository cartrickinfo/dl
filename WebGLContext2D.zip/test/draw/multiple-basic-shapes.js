ctx.fillStyle = 'red';
ctx.fillRect(50, 50, 100, 80);

ctx.strokeStyle = 'blue';
ctx.lineWidth = 3;
ctx.strokeRect(200, 50, 100, 80);

ctx.fillStyle = 'green';
ctx.beginPath();
ctx.arc(100, 200, 40, 0, Math.PI * 2);
ctx.fill();

ctx.strokeStyle = 'purple';
ctx.beginPath();
ctx.arc(250, 200, 40, 0, Math.PI * 2);
ctx.stroke();

// Expectation: filled red rectangle, empty blue rectangle, filled green circle, empty purple circle