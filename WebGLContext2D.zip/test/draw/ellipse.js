ctx.beginPath();
ctx.lineWidth = 5;
ctx.ellipse(200, 200, 50, 30, Math.PI / 4, 0, Math.PI * 2);
ctx.stroke();