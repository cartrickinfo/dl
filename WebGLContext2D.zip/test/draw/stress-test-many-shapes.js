const colors = ['red', 'blue', 'green', 'yellow'];

for (let i = 0; i < 20; i++) {
    const x = 50 + (i % 5) * 60;
    const y = 100 + Math.floor(i / 5) * 60;
    const color = colors[i % colors.length];

    ctx.fillStyle = color;

    if (i % 4 === 0) {
        // Rounded rectangle
        ctx.beginPath();
        ctx.roundRect(x, y, 40, 40, 8);
        ctx.fill();
    } else if (i % 4 === 1) {
        // Circle
        ctx.beginPath();
        ctx.arc(x + 20, y + 20, 18, 0, Math.PI * 2);
        ctx.fill();
    } else if (i % 4 === 2) {
        // Rotated oval
        ctx.beginPath();
        ctx.ellipse(x + 20, y + 20, 25, 15, Math.PI / 4, 0, Math.PI * 2);
        ctx.fill();
    } else {
        // Triangle
        ctx.beginPath();
        ctx.moveTo(x + 20, y + 5);
        ctx.lineTo(x + 5, y + 35);
        ctx.lineTo(x + 35, y + 35);
        ctx.closePath();
        ctx.fill();
    }
}

// Expectation: 5x4 grid of various colored shapes (rounded rectangle, circle, oval, triangle) without performance issues
