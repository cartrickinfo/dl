ctx.strokeStyle = 'orange';
ctx.lineWidth = 2;

// Regular oval
ctx.beginPath();
ctx.ellipse(150, 100, 60, 30, 0, 0, Math.PI * 2);
ctx.stroke();

// Ellipse rotated 45 degrees
ctx.strokeStyle = 'red';
ctx.beginPath();
ctx.ellipse(150, 200, 60, 30, Math.PI / 4, 0, Math.PI * 2);
ctx.stroke();

// Rotated semi-ellipse
ctx.strokeStyle = 'blue';
ctx.beginPath();
ctx.ellipse(150, 300, 50, 25, Math.PI / 6, 0, Math.PI);
ctx.stroke();

// Expectation: Orange horizontal oval, red 45° rotated oval, blue rotated semi-oval