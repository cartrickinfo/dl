ctx.fillStyle = '#8000ff';

// Identical corners
ctx.beginPath();
ctx.roundRect(50, 50, 80, 60, 15);
ctx.fill();

// Different corners
ctx.fillStyle = '#0068ff';
ctx.beginPath();
ctx.roundRect(150, 50, 80, 60, [5, 15, 25, 35]);
ctx.fill();

// Only two rounded corners
ctx.fillStyle = '#00ffb3';
ctx.beginPath();
ctx.roundRect(250, 50, 80, 60, [20, 20, 0, 0]);
ctx.fill();

// Expectation: Three rounded rectangles - one with the same corners, one with different corners, one with two rounded top corners
