ctx.save();

// Move and rotate
ctx.translate(150, 100);
ctx.rotate(Math.PI / 6);
ctx.scale(1.2, 0.8);

// Transformed square
ctx.fillStyle = '#E91E63';
ctx.fillRect(-25, -25, 50, 50);

ctx.restore();