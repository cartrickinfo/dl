// Complex scene with combined shapes
ctx.save();

// Background
ctx.fillStyle = '#ADD8E6';
ctx.fillRect(100, 50, 300, 200);

// Sun (circle + rays)
ctx.fillStyle = '#fff333';
ctx.beginPath();
ctx.arc(150, 100, 25, 0, Math.PI * 2);
ctx.fill();

ctx.strokeStyle = '#FFA500';
ctx.lineWidth = 3;
for (let i = 0; i < 8; i++) {
    const angle = (i * Math.PI * 2) / 8;
    ctx.beginPath();
    ctx.moveTo(150 + Math.cos(angle) * 30, 100 + Math.sin(angle) * 30);
    ctx.lineTo(150 + Math.cos(angle) * 40, 100 + Math.sin(angle) * 40);
    ctx.stroke();
}

// House (rectangle + triangle)
ctx.fillStyle = '#964B00';
ctx.fillRect(200, 150, 60, 50);

ctx.fillStyle = '#8B0000';
ctx.beginPath();
ctx.moveTo(185, 150);
ctx.lineTo(230, 120);
ctx.lineTo(275, 150);
ctx.closePath();
ctx.fill();

// Door (roundRect)
ctx.fillStyle = '#654321';
ctx.beginPath();
ctx.roundRect(220, 170, 20, 30, 3);
ctx.fill();

// Cloud (multiple ellipses)
ctx.fillStyle = '#fff';
ctx.beginPath();
ctx.ellipse(300, 80, 20, 15, 0, 0, Math.PI * 2);
ctx.ellipse(320, 85, 25, 18, 0, 0, Math.PI * 2);
ctx.ellipse(340, 80, 20, 15, 0, 0, Math.PI * 2);
ctx.fill();

ctx.restore();

// Expected: A complete scene containing a blue sky, yellow sun with rays, brown house with red roof and rounded door, and a white cloud