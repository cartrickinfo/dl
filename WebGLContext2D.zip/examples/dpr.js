function setupCanvas (devicePixelRatio = null) {
    const displayWidth = canvas.clientWidth;
    const displayHeight = canvas.clientHeight;

    canvas.width = displayWidth * devicePixelRatio;
    canvas.height = displayHeight * devicePixelRatio;

    canvas.style.width = displayWidth + 'px';
    canvas.style.height = displayHeight + 'px';

    ctx.scale(devicePixelRatio, devicePixelRatio);

    return {devicePixelRatio, displayWidth, displayHeight};
}

const customDPR = 2;
setupCanvas(customDPR);

ctx.fillRect(10, 10, 100, 100);