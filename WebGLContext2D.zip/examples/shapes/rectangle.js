// مستطیل قرمز
ctx.fillStyle = '#FF0000';
ctx.fillRect(50, 50, 100, 80);

// مستطیل آبی شفاف
ctx.globalAlpha = 0.7;
ctx.fillStyle = '#0000FF';
ctx.fillRect(80, 80, 100, 80);

// بازگردانی alpha
ctx.globalAlpha = 1.0;

// مستطیل سبز با stroke
ctx.strokeStyle = '#00AA00';
ctx.lineWidth = 3;
ctx.strokeRect(200, 50, 120, 100);
ctx.fillStyle = '#90EE90';
ctx.fillRect(200, 50, 120, 100);