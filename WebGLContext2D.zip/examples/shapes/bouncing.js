// FPS Logger
let fps = 0;
let lastTime = performance.now();
let frameCount = 0;

function updateFPS() {
    frameCount++;
    const currentTime = performance.now();
    if (currentTime - lastTime >= 1000) {
        fps = Math.round(frameCount * 1000 / (currentTime - lastTime));
        frameCount = 0;
        lastTime = currentTime;
        console.log('FPS:', fps);
    }
}

// مربع ها
const squares = [];
const numSquares = 1000;

// ایجاد مربع ها
for (let i = 0; i < numSquares; i++) {
    squares.push({
        x: Math.random() * (width - 20),
        y: Math.random() * (height - 20),
        vx: (Math.random() - 0.5) * 6,
        vy: (Math.random() - 0.5) * 6,
        size: Math.random() * 15 + 10,
        color: `hsl(${Math.random() * 360}, 70%, 50%)`
    });
}

function animate() {
    // پاک کردن canvas
    ctx.clearRect(0, 0, width, height);

    // حرکت و رسم مربع ها
    squares.forEach(square => {
        // حرکت
        square.x += square.vx;
        square.y += square.vy;

        // bouncing
        if (square.x <= 0 || square.x + square.size >= width) {
            square.vx = -square.vx;
        }
        if (square.y <= 0 || square.y + square.size >= height) {
            square.vy = -square.vy;
        }

        // رسم
        ctx.fillStyle = square.color;
        ctx.fillRect(square.x, square.y, square.size, square.size);
    });

    // نمایش FPS
    // ctx.fillStyle = 'black';
    // ctx.font = '20px Arial';
    // ctx.fillText('FPS: ' + fps, 10, 30);

    console.log(`FPS: ${fps}`)

    updateFPS();
    requestAnimationFrame(animate);
}

animate();
