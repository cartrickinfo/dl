// مثلث
ctx.beginPath();
ctx.moveTo(100, 250);
ctx.lineTo(150, 180);
ctx.lineTo(200, 250);
ctx.closePath();
ctx.fillStyle = '#F39C12';
ctx.fill();
ctx.strokeStyle = '#E67E22';
ctx.lineWidth = 2;
ctx.stroke();

// شش ضلعی
const centerX = 350;
const centerY = 220;
const radius = 50;
const sides = 6;

ctx.beginPath();
for (let i = 0; i < sides; i++) {
    const angle = (i * 2 * Math.PI) / sides;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);

    if (i === 0) {
        ctx.moveTo(x, y);
    } else {
        ctx.lineTo(x, y);
    }
}
ctx.closePath();
ctx.fillStyle = '#9B59B6';
ctx.fill();