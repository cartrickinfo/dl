// مستطیل گردوشه ساده
ctx.beginPath();
ctx.roundRect(50, 150, 120, 80, 15);
ctx.fillStyle = '#8E44AD';
ctx.fill();

// مستطیل گردوشه با radii مختلف
ctx.beginPath();
ctx.roundRect(200, 150, 120, 80, [20, 40, 60, 10]);
ctx.fillStyle = '#16A085';
ctx.fill();

// مستطیل گردوشه فقط stroke
ctx.beginPath();
ctx.roundRect(350, 150, 120, 80, 25);
ctx.strokeStyle = '#D35400';
ctx.lineWidth = 3;
ctx.stroke();