// پس زمینه بزرگتر
ctx.fillStyle = '#34495E';
ctx.fillRect(680, 350, 120, 120);

// رسم یک الگو
ctx.fillStyle = '#E74C3C';
ctx.fillRect(690, 360, 100, 100);

ctx.fillStyle = '#F1C40F';
ctx.fillRect(700, 370, 80, 80);

// حالا پاک کردن ناحیه مربعی از وسط
ctx.clearRect(720, 390, 40, 40);

// اضافه کردن یک دایره کوچک در ناحیه پاک شده
ctx.beginPath();
ctx.arc(740, 410, 8, 0, 2 * Math.PI);
ctx.fillStyle = '#2ECC71';
ctx.fill();