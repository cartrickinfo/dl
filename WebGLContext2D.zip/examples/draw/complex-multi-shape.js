// Test: صحنه پیچیده با اشکال ترکیبی
ctx.save();

// پس‌زمینه
ctx.fillStyle = '#ADD8E6';
ctx.fillRect(400, 50, 300, 200);

// خورشید (دایره + خطوط)
ctx.fillStyle = '#fff333';
ctx.beginPath();
ctx.arc(450, 100, 25, 0, Math.PI * 2);
ctx.fill();

ctx.strokeStyle = '#FFA500';
ctx.lineWidth = 3;
for (let i = 0; i < 8; i++) {
    const angle = (i * Math.PI * 2) / 8;
    ctx.beginPath();
    ctx.moveTo(450 + Math.cos(angle) * 30, 100 + Math.sin(angle) * 30);
    ctx.lineTo(450 + Math.cos(angle) * 40, 100 + Math.sin(angle) * 40);
    ctx.stroke();
}

// خانه (مستطیل + مثلث)
ctx.fillStyle = '#964B00';
ctx.fillRect(500, 150, 60, 50);

ctx.fillStyle = '#8B0000';
ctx.beginPath();
ctx.moveTo(485, 150);
ctx.lineTo(530, 120);
ctx.lineTo(575, 150);
ctx.closePath();
ctx.fill();

// درب (roundRect)
ctx.fillStyle = '#654321';
ctx.beginPath();
ctx.roundRect(520, 170, 20, 30, 3);
ctx.fill();

// ابر (ellipse های چندتایی)
ctx.fillStyle = '#fff';
ctx.beginPath();
ctx.ellipse(600, 80, 20, 15, 0, 0, Math.PI * 2);
ctx.ellipse(620, 85, 25, 18, 0, 0, Math.PI * 2);
ctx.ellipse(640, 80, 20, 15, 0, 0, Math.PI * 2);
ctx.fill();

ctx.restore();

// انتظار: صحنه کاملی شامل آسمان آبی، خورشید زرد با پرتوها، خانه قهوه‌ای با سقف قرمز و درب گرد، و ابر سفید
