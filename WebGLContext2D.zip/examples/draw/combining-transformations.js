ctx.save();

// حرکت و چرخش
ctx.translate(150, 100);
ctx.rotate(Math.PI / 6);
ctx.scale(1.2, 0.8);

// مربع متحول شده
ctx.fillStyle = '#E91E63';
ctx.fillRect(-25, -25, 50, 50);

ctx.restore();