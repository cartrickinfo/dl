try {
    // آرایه تصاویر در حال حرکت
    const movingImages = [];

// کلاس تصویر متحرک
    class MovingImage {
        constructor(src, x, y, vx, vy, size = 50) {
            this.image = new Image();
            this.x = x;
            this.y = y;
            this.vx = vx; // سرعت افقی
            this.vy = vy; // سرعت عمودی
            this.size = size;
            this.loaded = false;

            this.image.onload = () => {
                this.loaded = true;
            };
            this.image.src = src;
        }

        update() {
            this.x += this.vx;
            this.y += this.vy;

            // بازتاب از دیوارها
            if (this.x <= 0 || this.x >= canvasWebGL.width - this.size) {
                this.vx = -this.vx;
                this.x = Math.max(0, Math.min(canvasWebGL.width - this.size, this.x));
            }

            if (this.y <= 0 || this.y >= canvasWebGL.height - this.size) {
                this.vy = -this.vy;
                this.y = Math.max(0, Math.min(canvasWebGL.height - this.size, this.y));
            }
        }

        draw(ctx) {
            if (this.loaded) {
                ctx.drawImage(this.image, this.x, this.y, this.size, this.size);
            }
        }
    }

// ایجاد تصاویر متحرک
    for (let i = 0; i < 10; i++) {
        const x = Math.random() * (canvasWebGL.width - 50);
        const y = Math.random() * (canvasWebGL.height - 50);
        const vx = (Math.random() - 0.5) * 6; // سرعت بین -3 تا 3
        const vy = (Math.random() - 0.5) * 6;

        // استفاده از تصاویر مختلف (یا همان تصویر)
        const imageSrc = `./assets/character.png`;

        movingImages.push(new MovingImage(imageSrc, x, y, vx, vy));
    }

// متغیرهای FPS
    let lastTime = 0;
    let frameCount = 0;
    let fps = 0;

// حلقه انیمیشن
    function animate(currentTime) {
        // محاسبه FPS
        frameCount++;
        if (currentTime - lastTime >= 1000) {
            fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
            frameCount = 0;
            lastTime = currentTime;
        }

        // پاک کردن canvas
        ctx.clearRect(0, 0, canvasWebGL.width, canvasWebGL.height);

        // رسم background
        ctx.fillStyle = 'rgba(50, 50, 50, 0.1)';
        ctx.fillRect(0, 0, canvasWebGL.width, canvasWebGL.height);

        // به‌روزرسانی و رسم تصاویر
        movingImages.forEach(img => {
            img.update();
            img.draw(ctx);
        });
        console.log(fps)
        requestAnimationFrame(animate);
    }

// شروع انیمیشن
    requestAnimationFrame(animate);
} catch (e) {
    console.log(e)
}