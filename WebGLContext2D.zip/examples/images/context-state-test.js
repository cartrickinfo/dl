// Basic image drawing
const basicImg = new Image();
basicImg.onload = () => {
    // drawImage(image, dx, dy)
    ctx.drawImage(basicImg, 50, 180);
};
basicImg.src = './assets/imagine_ai_3.png';

// WebGL state
const beforeDraw = ctx.gl.getParameter(ctx.gl.CURRENT_PROGRAM);
ctx.drawImage(basicImg, 0, 0);
const afterDraw = ctx.gl.getParameter(ctx.gl.CURRENT_PROGRAM);

console.log('Program state preserved:', beforeDraw === afterDraw);
