/**
 * Drawing operations - fill, stroke, clearRect, and triangulation.
 * Integrates with BatchRenderer for efficient GPU submission.
 * Now supports WebGLPattern fills and line dashes.
 */

import earcut from '../tools/earcut.js';
import { WebGLLinearGradient, WebGLRadialGradient, WebGLConicGradient, WebGLPattern } from './gradient.js';

const OP_LINEAR_GRAD = 1;
const OP_RADIAL_GRAD = 2;
const OP_CONIC_GRAD = 3;

/**
 * Triangulate contours using earcut.
 * Returns flat array of triangle vertices [x,y, x,y, x,y, ...].
 */
export function triangulateContours(contours) {
    const allTriangles = [];

    for (const contour of contours) {
        if (!contour || contour.length < 6) continue;

        try {
            const indices = earcut(contour);
            if (!indices || indices.length === 0) {
                fanTriangulate(contour, allTriangles);
                continue;
            }
            for (let i = 0; i < indices.length; i++) {
                const idx = indices[i] * 2;
                allTriangles.push(contour[idx], contour[idx + 1]);
            }
        } catch (e) {
            fanTriangulate(contour, allTriangles);
        }
    }

    return allTriangles;
}

function fanTriangulate(contour, out) {
    const count = Math.floor(contour.length / 2);
    if (count < 3) return;
    const x0 = contour[0], y0 = contour[1];
    for (let i = 1; i < count - 1; i++) {
        out.push(x0, y0, contour[i * 2], contour[i * 2 + 1], contour[(i + 1) * 2], contour[(i + 1) * 2 + 1]);
    }
}

/** Parse color and return [r,g,b,a] */
function parseColor(parser, style) {
    if (typeof style === 'string') {
        return parser.parse(style);
    }
    return [0, 0, 0, 1];
}

/**
 * Draw triangles with style (solid, gradient, or pattern).
 */
export function drawTriangles(renderer, triangles, style, globalAlpha, matrix, colorParser, dpr) {
    if (!triangles || triangles.length === 0) return;
    dpr = dpr || 1;

    if (style instanceof WebGLLinearGradient) {
        const texture = style._getTexture(renderer.gl);
        if (!texture) return;
        renderer.drawGradientTriangles(triangles, OP_LINEAR_GRAD, texture,
            globalAlpha, matrix,
            style.x0 * dpr, style.y0 * dpr, style.x1 * dpr, style.y1 * dpr, 0, 0, 0);
        return;
    }

    if (style instanceof WebGLRadialGradient) {
        const texture = style._getTexture(renderer.gl);
        if (!texture) return;
        renderer.drawGradientTriangles(triangles, OP_RADIAL_GRAD, texture,
            globalAlpha, matrix,
            style.x0 * dpr, style.y0 * dpr, style.r0 * dpr, style.r1 * dpr, 0, 0, 0);
        return;
    }

    if (style instanceof WebGLConicGradient) {
        const texture = style._getTexture(renderer.gl);
        if (!texture) return;
        renderer.drawGradientTriangles(triangles, OP_CONIC_GRAD, texture,
            globalAlpha, matrix,
            0, 0, 0, 0, style.x * dpr, style.y * dpr, style.angle);
        return;
    }

    if (style instanceof WebGLPattern) {
        const texture = style._getTexture(renderer.gl);
        if (!texture) return;
        // For patterns, we use texture mode with repeating UVs
        // Calculate bounding box of triangles
        let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        for (let i = 0; i < triangles.length; i += 2) {
            minX = Math.min(minX, triangles[i]);
            minY = Math.min(minY, triangles[i + 1]);
            maxX = Math.max(maxX, triangles[i]);
            maxY = Math.max(maxY, triangles[i + 1]);
        }
        
        // Draw each triangle with pattern UVs
        for (let i = 0; i < triangles.length; i += 6) {
            const t = triangles;
            const verts = [
                t[i], t[i + 1], t[i + 2], t[i + 3], t[i + 4], t[i + 5]
            ];
            // Calculate UVs based on position within bounding box
            const u1 = (verts[0] - minX) / (maxX - minX);
            const v1 = (verts[1] - minY) / (maxY - minY);
            const u2 = (verts[2] - minX) / (maxX - minX);
            const v2 = (verts[3] - minY) / (maxY - minY);
            const u3 = (verts[4] - minX) / (maxX - minX);
            const v3 = (verts[5] - minY) / (maxY - minY);
            
            renderer.drawPatternTriangles(verts, texture, globalAlpha, matrix,
                u1, v1, u2, v2, u3, v3, style._width || 1, style._height || 1);
        }
        return;
    }

    // Solid color
    const cp = colorParser || { parse: s => [0, 0, 0, 1] };
    const color = cp.parse(style);
    renderer.drawSolidTriangles(triangles, color[0], color[1], color[2], color[3] * globalAlpha, matrix);
}

/** Draw a filled rectangle */
export function fillRect(renderer, x, y, w, h, style, globalAlpha, matrix, colorParser, gl, dpr) {
    dpr = dpr || 1;
    
    const verts = [
        x, y, x + w, y, x, y + h,
        x + w, y, x + w, y + h, x, y + h
    ];
    
    if (style instanceof WebGLLinearGradient) {
        const texture = style._getTexture(gl);
        if (texture) {
            renderer.drawGradientTriangles(verts, OP_LINEAR_GRAD, texture,
                globalAlpha, matrix, style.x0 * dpr, style.y0 * dpr, style.x1 * dpr, style.y1 * dpr, 0, 0, 0);
            return;
        }
    }
    if (style instanceof WebGLRadialGradient) {
        const texture = style._getTexture(gl);
        if (texture) {
            renderer.drawGradientTriangles(verts, OP_RADIAL_GRAD, texture,
                globalAlpha, matrix, style.x0 * dpr, style.y0 * dpr, style.r0 * dpr, style.r1 * dpr, 0, 0, 0);
            return;
        }
    }
    if (style instanceof WebGLConicGradient) {
        const texture = style._getTexture(gl);
        if (texture) {
            renderer.drawGradientTriangles(verts, OP_CONIC_GRAD, texture,
                globalAlpha, matrix, 0, 0, 0, 0, style.x * dpr, style.y * dpr, style.angle);
            return;
        }
    }
    if (style instanceof WebGLPattern) {
        const texture = style._getTexture(gl);
        if (texture) {
            const pw = style._width || w;
            const ph = style._height || h;
            renderer.drawPatternTexturedRect(x, y, w, h, texture, globalAlpha, matrix, pw, ph);
            return;
        }
    }

    // Solid color
    const color = colorParser.parse(style);
    renderer.drawSolidRect(x, y, w, h, color[0], color[1], color[2], color[3] * globalAlpha, matrix);
}

/** Draw stroked rectangle */
export function strokeRect(renderer, x, y, w, h, style, globalAlpha, lineWidth, matrix, colorParser) {
    const color = colorParser.parse(style);
    const r = color[0], g = color[1], b = color[2], a = color[3] * globalAlpha;
    const hw = lineWidth / 2;

    // Top
    renderer.drawSolidRect(x - hw, y - hw, w + lineWidth, lineWidth, r, g, b, a, matrix);
    // Bottom
    renderer.drawSolidRect(x - hw, y + h - hw, w + lineWidth, lineWidth, r, g, b, a, matrix);
    // Left
    renderer.drawSolidRect(x - hw, y + hw, lineWidth, h - lineWidth, r, g, b, a, matrix);
    // Right
    renderer.drawSolidRect(x + w - hw, y + hw, lineWidth, h - lineWidth, r, g, b, a, matrix);
}

/** Clear rectangle */
export function clearRect(gl, renderer, x, y, w, h, canvasWidth, canvasHeight) {
    if (w <= 0 || h <= 0) return;
    renderer.present();

    // Coordinates are already in buffer-space (canvas pixel coordinates)
    // Convert to GL scissor coordinates (origin at bottom-left)
    const px = Math.floor(x);
    const py = Math.floor(canvasHeight - y - h);
    const pw = Math.ceil(w);
    const ph = Math.ceil(h);

    if (x <= 0 && y <= 0 && w >= canvasWidth && h >= canvasHeight) {
        gl.clearColor(0, 0, 0, 0);
        gl.clear(gl.COLOR_BUFFER_BIT);
        return;
    }

    gl.enable(gl.SCISSOR_TEST);
    gl.scissor(px, py, pw, ph);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.disable(gl.SCISSOR_TEST);
}

/**
 * Get stroke vertices with optional line dash applied.
 */
export function getStrokeVertices(pathBuilder, lineWidth, lineCap, lineJoin, miterLimit, lineDash) {
    // If line dash is specified, apply it to the contours
    if (lineDash && lineDash.length > 0) {
        return getDashedStrokeVertices(pathBuilder, lineWidth, lineCap, lineJoin, miterLimit, lineDash);
    }
    return pathBuilder.getStrokeVertices(lineWidth, lineCap, lineJoin, miterLimit);
}

/**
 * Generate dashed stroke vertices by breaking contours at dash boundaries.
 */
function getDashedStrokeVertices(pathBuilder, lineWidth, lineCap, lineJoin, miterLimit, lineDash) {
    const contours = pathBuilder.getContours();
    const result = [];
    const halfWidth = lineWidth / 2;

    for (const contour of contours) {
        if (contour.length < 4) continue;
        
        // Flatten contour to line segments
        const segments = [];
        const count = contour.length / 2;
        for (let i = 0; i < count - 1; i++) {
            const x1 = contour[i * 2], y1 = contour[i * 2 + 1];
            const x2 = contour[(i + 1) * 2], y2 = contour[(i + 1) * 2 + 1];
            const dx = x2 - x1, dy = y2 - y1;
            const len = Math.hypot(dx, dy);
            if (len < 0.001) continue;
            segments.push({ x1, y1, x2, y2, dx, dy, len });
        }

        // Apply dash pattern
        let dashIndex = 0;
        let dashAccum = 0;
        let drawing = true; // Start with draw
        
        for (const seg of segments) {
            let segProgress = 0;
            
            while (segProgress < seg.len) {
                const dashLen = lineDash[dashIndex % lineDash.length];
                const remaining = seg.len - segProgress;
                const drawLen = Math.min(dashLen - dashAccum, remaining);
                
                if (drawing && drawLen > 0) {
                    const t1 = segProgress / seg.len;
                    const t2 = (segProgress + drawLen) / seg.len;
                    const sx = seg.x1 + seg.dx * t1;
                    const sy = seg.y1 + seg.dy * t1;
                    const ex = seg.x1 + seg.dx * t2;
                    const ey = seg.y1 + seg.dy * t2;
                    
                    // Add dash segment as stroke geometry
                    _strokeSegment(sx, sy, ex, ey, halfWidth, lineCap, result);
                }
                
                dashAccum += drawLen;
                segProgress += drawLen;
                
                if (Math.abs(dashAccum - dashLen) < 0.001 || dashAccum >= dashLen) {
                    dashAccum = 0;
                    dashIndex++;
                    drawing = !drawing;
                }
            }
        }
    }

    return result;
}

/**
 * Generate stroke geometry for a single segment.
 */
function _strokeSegment(x1, y1, x2, y2, hw, cap, out) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const len = Math.hypot(dx, dy);
    if (len < 0.001) return;

    const nx = -dy / len * hw;
    const ny = dx / len * hw;

    // Main quad
    out.push(
        x1 + nx, y1 + ny,
        x1 - nx, y1 - ny,
        x2 + nx, y2 + ny,
        x1 - nx, y1 - ny,
        x2 - nx, y2 - ny,
        x2 + nx, y2 + ny
    );

    // Caps
    if (cap === 'round') {
        // Round cap at start
        _addRoundCap(x1, y1, dx, dy, hw, out);
        // Round cap at end
        _addRoundCap(x2, y2, -dx, -dy, hw, out);
    } else if (cap === 'square') {
        // Square extension at start
        const ex = -dx / len * hw;
        const ey = -dy / len * hw;
        const sx = x1 + ex, sy = y1 + ey;
        out.push(
            x1 + nx, y1 + ny,
            x1 - nx, y1 - ny,
            sx + nx, sy + ny,
            x1 - nx, y1 - ny,
            sx - nx, sy - ny,
            sx + nx, sy + ny
        );
        // Square extension at end
        const ex2 = dx / len * hw;
        const ey2 = dy / len * hw;
        const sx2 = x2 + ex2, sy2 = y2 + ey2;
        out.push(
            x2 + nx, y2 + ny,
            x2 - nx, y2 - ny,
            sx2 + nx, sy2 + ny,
            x2 - nx, y2 - ny,
            sx2 - nx, sy2 - ny,
            sx2 + nx, sy2 + ny
        );
    }
}

function _addRoundCap(cx, cy, dx, dy, hw, out) {
    const len = Math.hypot(dx, dy);
    if (len < 0.001) return;
    
    const nx = -dy / len;
    const ny = dx / len;
    const angle = Math.atan2(ny, nx);
    const steps = 8;
    
    for (let i = 0; i < steps; i++) {
        const a1 = angle + Math.PI / 2 - (Math.PI * (i / steps));
        const a2 = angle + Math.PI / 2 - (Math.PI * ((i + 1) / steps));
        out.push(
            cx, cy,
            cx + Math.cos(a1) * hw, cy + Math.sin(a1) * hw,
            cx + Math.cos(a2) * hw, cy + Math.sin(a2) * hw
        );
    }
}
