/**
 * Image operations - drawImage, createImageData, getImageData, putImageData.
 */

import { matrixToArray } from '../tools/math.js';

/**
 * Draw an image onto the canvas.
 * Supports all 3 drawImage() signatures from the Canvas spec.
 */
export function drawImage(renderer, textureCache, image, args, globalAlpha, currentTransform, canvasWidth, canvasHeight) {
    let sx = 0, sy = 0, sw, sh, dx, dy, dw, dh;

    // Get source dimensions
    if (image.naturalWidth !== undefined) {
        sw = image.naturalWidth;
        sh = image.naturalHeight;
    } else if (image.videoWidth !== undefined) {
        sw = image.videoWidth;
        sh = image.videoHeight;
    } else if (image.width !== undefined) {
        sw = image.width;
        sh = image.height;
    } else {
        return; // Invalid source
    }

    if (sw === 0 || sh === 0) return;

    // Parse argument variants
    if (args.length === 2) {
        [dx, dy] = args;
        dw = sw;
        dh = sh;
    } else if (args.length === 4) {
        [dx, dy, dw, dh] = args;
    } else if (args.length === 8) {
        [sx, sy, sw, sh, dx, dy, dw, dh] = args;
    } else {
        throw new TypeError('Invalid number of arguments to drawImage');
    }

    // Validate
    if ([sx, sy, sw, sh, dx, dy, dw, dh].some(v => isNaN(Number(v)))) return;

    // Get or create texture
    const texture = textureCache.get(image);
    if (!texture) return;

    // Calculate UVs
    const imgW = image.naturalWidth || image.videoWidth || image.width || sw;
    const imgH = image.naturalHeight || image.videoHeight || image.height || sh;
    const u1 = sx / imgW;
    const v1 = sy / imgH;
    const u2 = (sx + sw) / imgW;
    const v2 = (sy + sh) / imgH;

    // Use untransformed corners - the shader will apply the transform matrix
    const x1 = dx, y1 = dy;
    const x2 = dx + dw, y2 = dy;
    const x3 = dx, y3 = dy + dh;
    const x4 = dx + dw, y4 = dy + dh;

    renderer.drawTexturedQuad(
        x1, y1, x2, y2, x3, y3, x4, y4,
        u1, v1, u2, v2,
        1, 1, 1, globalAlpha,
        matrixToArray(currentTransform),
        texture
    );
}

/**
 * Create ImageData object.
 */
export function createImageData(sw, sh, sh2) {
    // Handle createImageData(imagedata) overload
    if (typeof sw === 'object' && sw && sw.data) {
        return new ImageData(
            new Uint8ClampedArray(sw.data),
            sw.width,
            sw.height
        );
    }

    // Handle createImageData(sw, sh) or createImageData(sw, sh, settings)
    const width = Math.floor(Number(sw));
    const height = Math.floor(Number(sh));

    if (isNaN(width) || isNaN(height) || width <= 0 || height <= 0) {
        throw new Error('Invalid dimensions for createImageData');
    }

    return new ImageData(width, height);
}

/**
 * Get pixel data from the canvas.
 */
export function getImageData(gl, sx, sy, sw, sh) {
    sx = Math.floor(Number(sx));
    sy = Math.floor(Number(sy));
    sw = Math.floor(Number(sw));
    sh = Math.floor(Number(sh));

    if ([sx, sy, sw, sh].some(isNaN) || sw === 0 || sh === 0) {
        throw new Error('Invalid rectangle for getImageData');
    }

    const absW = Math.abs(sw);
    const absH = Math.abs(sh);
    // Coordinates are in buffer-space; GL readPixels needs bottom-left origin
    const x = sx;
    const y = Math.floor(gl.canvas.height - (sy + sh));
    const w = absW;
    const h = absH;

    const pixels = new Uint8Array(absW * absH * 4);
    gl.readPixels(x, y, w, h, gl.RGBA, gl.UNSIGNED_BYTE, pixels);

    // Flip Y and convert to ImageData format
    const flipped = new Uint8ClampedArray(absW * absH * 4);
    for (let row = 0; row < absH; row++) {
        const srcRow = absH - 1 - row;
        for (let col = 0; col < absW; col++) {
            const srcIdx = (srcRow * absW + col) * 4;
            const dstIdx = (row * absW + col) * 4;
            flipped[dstIdx] = pixels[srcIdx];
            flipped[dstIdx + 1] = pixels[srcIdx + 1];
            flipped[dstIdx + 2] = pixels[srcIdx + 2];
            flipped[dstIdx + 3] = pixels[srcIdx + 3];
        }
    }

    return new ImageData(flipped, absW, absH);
}

/**
 * Put pixel data onto the canvas.
 */
export function putImageData(gl, renderer, imageData, dx, dy, dirtyX = 0, dirtyY = 0, dirtyWidth, dirtyHeight) {
    if (!imageData || !imageData.data) {
        throw new TypeError('Invalid ImageData');
    }

    dx = Math.floor(Number(dx));
    dy = Math.floor(Number(dy));
    dirtyX = Math.floor(Number(dirtyX));
    dirtyY = Math.floor(Number(dirtyY));
    dirtyWidth = dirtyWidth !== undefined ? Math.floor(Number(dirtyWidth)) : imageData.width;
    dirtyHeight = dirtyHeight !== undefined ? Math.floor(Number(dirtyHeight)) : imageData.height;

    if ([dx, dy, dirtyX, dirtyY, dirtyWidth, dirtyHeight].some(isNaN)) return;

    renderer.present(); // Flush any pending draws

    const width = imageData.width;
    const height = imageData.height;

    // Clamp dirty rect
    dirtyX = Math.max(0, dirtyX);
    dirtyY = Math.max(0, dirtyY);
    dirtyWidth = Math.min(dirtyWidth, width - dirtyX);
    dirtyHeight = Math.min(dirtyHeight, height - dirtyY);

    if (dirtyWidth <= 0 || dirtyHeight <= 0) return;

    // Flip Y for WebGL
    const flippedData = new Uint8ClampedArray(dirtyWidth * dirtyHeight * 4);
    for (let y = 0; y < dirtyHeight; y++) {
        const srcY = dirtyHeight - 1 - y;
        for (let x = 0; x < dirtyWidth; x++) {
            const srcIdx = ((srcY + dirtyY) * width + (x + dirtyX)) * 4;
            const dstIdx = (y * dirtyWidth + x) * 4;
            flippedData[dstIdx] = imageData.data[srcIdx];
            flippedData[dstIdx + 1] = imageData.data[srcIdx + 1];
            flippedData[dstIdx + 2] = imageData.data[srcIdx + 2];
            flippedData[dstIdx + 3] = imageData.data[srcIdx + 3];
        }
    }

    // Create temp texture
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, dirtyWidth, dirtyHeight, 0, gl.RGBA, gl.UNSIGNED_BYTE, flippedData);

    // Draw with identity transform (spec requirement)
    // We use a simple full-screen quad approach
    const vs = `
        attribute vec2 a_pos;
        attribute vec2 a_uv;
        varying vec2 v_uv;
        uniform vec2 u_offset;
        uniform vec2 u_resolution;
        uniform vec2 u_size;
        void main() {
            vec2 pos = (a_pos * u_size + u_offset) / u_resolution * 2.0 - 1.0;
            pos.y = -pos.y;
            gl_Position = vec4(pos, 0.0, 1.0);
            v_uv = a_uv;
        }
    `;
    const fs = `
        precision mediump float;
        varying vec2 v_uv;
        uniform sampler2D u_tex;
        void main() {
            gl_FragColor = texture2D(u_tex, v_uv);
        }
    `;

    const prog = createTempProgram(gl, vs, fs);
    if (!prog) {
        gl.deleteTexture(texture);
        return;
    }

    const locPos = gl.getAttribLocation(prog, 'a_pos');
    const locUv = gl.getAttribLocation(prog, 'a_uv');
    const locOffset = gl.getUniformLocation(prog, 'u_offset');
    const locRes = gl.getUniformLocation(prog, 'u_resolution');
    const locSize = gl.getUniformLocation(prog, 'u_size');
    const locTex = gl.getUniformLocation(prog, 'u_tex');

    const vertices = new Float32Array([
        0, 0, 0, 0,
        1, 0, 1, 0,
        0, 1, 0, 1,
        1, 0, 1, 0,
        1, 1, 1, 1,
        0, 1, 0, 1
    ]);

    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(locPos);
    gl.vertexAttribPointer(locPos, 2, gl.FLOAT, false, 16, 0);
    gl.enableVertexAttribArray(locUv);
    gl.vertexAttribPointer(locUv, 2, gl.FLOAT, false, 16, 8);

    gl.useProgram(prog);
    gl.uniform2f(locOffset, dx + dirtyX, dy + dirtyY);
    gl.uniform2f(locRes, gl.canvas.width, gl.canvas.height);
    gl.uniform2f(locSize, dirtyWidth, dirtyHeight);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.uniform1i(locTex, 0);

    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    gl.drawArrays(gl.TRIANGLES, 0, 6);

    // Cleanup
    gl.deleteBuffer(buf);
    gl.deleteTexture(texture);
    gl.deleteProgram(prog);
}

function createTempProgram(gl, vsSrc, fsSrc) {
    const vs = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vs, vsSrc);
    gl.compileShader(vs);

    const fs = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fs, fsSrc);
    gl.compileShader(fs);

    const prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);

    gl.deleteShader(vs);
    gl.deleteShader(fs);

    return prog;
}
