/**
 * State management - save/restore, transforms, and style properties.
 * Mirrors CanvasRenderingContext2D state behavior exactly.
 */

/** Default state factory */
export function createDefaultState() {
    return {
        // Transform
        transform: new DOMMatrix(),

        // Styles
        globalAlpha: 1,
        fillStyle: '#000000',
        strokeStyle: '#000000',

        // Line
        lineWidth: 1,
        lineCap: 'butt',
        lineJoin: 'miter',
        miterLimit: 10,
        lineDash: new Float64Array(),
        lineDashOffset: 0,

        // Shadow
        shadowBlur: 0,
        shadowColor: 'rgba(0,0,0,0)',
        shadowOffsetX: 0,
        shadowOffsetY: 0,

        // Compositing
        globalCompositeOperation: 'source-over',
        imageSmoothingEnabled: true,
        imageSmoothingQuality: 'low',
        filter: 'none',

        // Text
        font: '10px sans-serif',
        textAlign: 'start',
        textBaseline: 'alphabetic',
        direction: 'inherit',
        letterSpacing: '0px',
        wordSpacing: '0px',
        textRendering: 'auto',
        fontKerning: 'auto',
        fontStretch: 'normal',
        fontVariantCaps: 'normal',
        lang: 'inherit',

        // Clip depth at time of save
        clipDepth: 0
    };
}

/** State stack manager */
export class StateStack {
    constructor() {
        this.stack = [];
        this.current = createDefaultState();
    }

    /** Save current state onto stack */
    save() {
        this.stack.push({
            transform: new DOMMatrix(this.current.transform),
            globalAlpha: this.current.globalAlpha,
            fillStyle: this.current.fillStyle,
            strokeStyle: this.current.strokeStyle,
            lineWidth: this.current.lineWidth,
            lineCap: this.current.lineCap,
            lineJoin: this.current.lineJoin,
            miterLimit: this.current.miterLimit,
            lineDash: new Float64Array(this.current.lineDash),
            lineDashOffset: this.current.lineDashOffset,
            shadowBlur: this.current.shadowBlur,
            shadowColor: this.current.shadowColor,
            shadowOffsetX: this.current.shadowOffsetX,
            shadowOffsetY: this.current.shadowOffsetY,
            globalCompositeOperation: this.current.globalCompositeOperation,
            imageSmoothingEnabled: this.current.imageSmoothingEnabled,
            imageSmoothingQuality: this.current.imageSmoothingQuality,
            filter: this.current.filter,
            font: this.current.font,
            textAlign: this.current.textAlign,
            textBaseline: this.current.textBaseline,
            direction: this.current.direction,
            letterSpacing: this.current.letterSpacing,
            wordSpacing: this.current.wordSpacing,
            textRendering: this.current.textRendering,
            fontKerning: this.current.fontKerning,
            fontStretch: this.current.fontStretch,
            fontVariantCaps: this.current.fontVariantCaps,
            lang: this.current.lang,
            clipDepth: this.current.clipDepth
        });
    }

    /** Restore state from stack */
    restore() {
        if (this.stack.length === 0) return;
        const s = this.stack.pop();
        Object.assign(this.current, s);
    }

    /** Reset all state */
    reset() {
        this.current = createDefaultState();
        this.stack = [];
    }

    // --- Transform shortcuts ---

    // Internal access to the DOMMatrix - use getTransform() for public API
    get _transform() { return this.current.transform; }

    scale(x, y) {
        this.current.transform = this.current.transform.scale(x, y ?? x);
    }

    translate(x, y) {
        this.current.transform = this.current.transform.translate(x, y);
    }

    rotate(angle) {
        this.current.transform = this.current.transform.rotate(angle * 180 / Math.PI);
    }

    setTransform(a, b, c, d, e, f) {
        if (arguments.length === 1 && typeof a === 'object') {
            this.current.transform = new DOMMatrix(a);
        } else {
            this.current.transform = new DOMMatrix([a, b, c, d, e, f]);
        }
    }

    resetTransform() {
        this.current.transform = new DOMMatrix();
    }

    transform(a, b, c, d, e, f) {
        const m = new DOMMatrix([a, b, c, d, e, f]);
        this.current.transform = this.current.transform.multiply(m);
    }

    getTransform() {
        return new DOMMatrix(this.current.transform);
    }

    // --- Property accessors ---

    get globalAlpha() { return this.current.globalAlpha; }
    set globalAlpha(v) {
        const val = Number(v);
        if (!isNaN(val)) this.current.globalAlpha = clamp(val, 0, 1);
    }

    get fillStyle() { return this.current.fillStyle; }
    set fillStyle(v) { this.current.fillStyle = v; }

    get strokeStyle() { return this.current.strokeStyle; }
    set strokeStyle(v) { this.current.strokeStyle = v; }

    get lineWidth() { return this.current.lineWidth; }
    set lineWidth(v) {
        const val = Number(v);
        if (!isNaN(val) && val >= 0) this.current.lineWidth = val;
    }

    get lineCap() { return this.current.lineCap; }
    set lineCap(v) {
        if (['butt', 'round', 'square'].includes(v)) this.current.lineCap = v;
    }

    get lineJoin() { return this.current.lineJoin; }
    set lineJoin(v) {
        if (['miter', 'round', 'bevel'].includes(v)) this.current.lineJoin = v;
    }

    get miterLimit() { return this.current.miterLimit; }
    set miterLimit(v) {
        const val = Number(v);
        if (!isNaN(val) && val >= 1) this.current.miterLimit = val;
    }

    get lineDashOffset() { return this.current.lineDashOffset; }
    set lineDashOffset(v) {
        const val = Number(v);
        if (!isNaN(val)) this.current.lineDashOffset = val;
    }

    get shadowBlur() { return this.current.shadowBlur; }
    set shadowBlur(v) {
        const val = Number(v);
        if (!isNaN(val) && val >= 0) this.current.shadowBlur = val;
    }

    get shadowColor() { return this.current.shadowColor; }
    set shadowColor(v) { this.current.shadowColor = String(v); }

    get shadowOffsetX() { return this.current.shadowOffsetX; }
    set shadowOffsetX(v) {
        const val = Number(v);
        if (!isNaN(val)) this.current.shadowOffsetX = val;
    }

    get shadowOffsetY() { return this.current.shadowOffsetY; }
    set shadowOffsetY(v) {
        const val = Number(v);
        if (!isNaN(val)) this.current.shadowOffsetY = val;
    }

    get globalCompositeOperation() { return this.current.globalCompositeOperation; }
    set globalCompositeOperation(v) {
        const ops = [
            'source-over', 'source-in', 'source-out', 'source-atop',
            'destination-over', 'destination-in', 'destination-out', 'destination-atop',
            'lighter', 'copy', 'xor', 'multiply', 'screen', 'overlay', 'darken',
            'lighten', 'color-dodge', 'color-burn', 'hard-light', 'soft-light',
            'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity'
        ];
        if (ops.includes(v)) this.current.globalCompositeOperation = v;
    }

    get imageSmoothingEnabled() { return this.current.imageSmoothingEnabled; }
    set imageSmoothingEnabled(v) { this.current.imageSmoothingEnabled = Boolean(v); }

    get imageSmoothingQuality() { return this.current.imageSmoothingQuality; }
    set imageSmoothingQuality(v) {
        if (['low', 'medium', 'high'].includes(v)) this.current.imageSmoothingQuality = v;
    }

    get filter() { return this.current.filter; }
    set filter(v) { this.current.filter = String(v); }

    get font() { return this.current.font; }
    set font(v) { this.current.font = String(v); }

    get textAlign() { return this.current.textAlign; }
    set textAlign(v) {
        if (['start', 'end', 'left', 'right', 'center'].includes(v)) this.current.textAlign = v;
    }

    get textBaseline() { return this.current.textBaseline; }
    set textBaseline(v) {
        if (['top', 'hanging', 'middle', 'alphabetic', 'ideographic', 'bottom'].includes(v))
            this.current.textBaseline = v;
    }

    get direction() { return this.current.direction; }
    set direction(v) {
        if (['ltr', 'rtl', 'inherit'].includes(v)) this.current.direction = v;
    }

    get letterSpacing() { return this.current.letterSpacing; }
    set letterSpacing(v) { this.current.letterSpacing = String(v); }

    get wordSpacing() { return this.current.wordSpacing; }
    set wordSpacing(v) { this.current.wordSpacing = String(v); }

    get textRendering() { return this.current.textRendering; }
    set textRendering(v) {
        if (['auto', 'optimizeSpeed', 'optimizeLegibility', 'geometricPrecision'].includes(v))
            this.current.textRendering = v;
    }

    get fontKerning() { return this.current.fontKerning; }
    set fontKerning(v) {
        if (['auto', 'normal', 'none'].includes(v)) this.current.fontKerning = v;
    }

    get fontStretch() { return this.current.fontStretch; }
    set fontStretch(v) {
        const valid = ['normal', 'ultra-condensed', 'extra-condensed', 'condensed', 'semi-condensed',
            'semi-expanded', 'expanded', 'extra-expanded', 'ultra-expanded', 'narrower', 'wider'];
        if (valid.includes(v)) this.current.fontStretch = v;
    }

    get fontVariantCaps() { return this.current.fontVariantCaps; }
    set fontVariantCaps(v) {
        const valid = ['normal', 'small-caps', 'all-small-caps', 'petite-caps', 'all-petite-caps',
            'unicase', 'titling-caps'];
        if (valid.includes(v)) this.current.fontVariantCaps = v;
    }

    get lang() { return this.current.lang; }
    set lang(v) { this.current.lang = String(v); }
}

function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
}

export default StateStack;
