/**
 * Path2D - Canvas 2D Path2D API implementation.
 * Supports path construction from commands or SVG path strings.
 */

import { PathBuilder } from './path.js';
import { flattenCubicBezier, flattenQuadraticBezier, flattenArc } from '../tools/math.js';

class Path2D {
    constructor(arg) {
        this._pathBuilder = new PathBuilder();

        if (typeof arg === 'string') {
            // Parse SVG path string
            this._parseSVGPath(arg);
        } else if (arg && arg instanceof Path2D) {
            // Deep copy from another Path2D
            this._copyFrom(arg);
        }
    }

    _copyFrom(other) {
        const otherContours = other._pathBuilder.getContours();
        this._pathBuilder.reset();
        for (const contour of otherContours) {
            if (contour.length < 2) continue;
            this._pathBuilder.moveTo(contour[0], contour[1]);
            for (let i = 2; i < contour.length; i += 2) {
                this._pathBuilder.lineTo(contour[i], contour[i + 1]);
            }
        }
    }

    addPath(path, transform) {
        if (!path || !(path instanceof Path2D)) {
            throw new TypeError('Argument 1 must be a Path2D');
        }
        
        const otherContours = path._pathBuilder.getContours();
        
        if (transform) {
            // Apply transform to each contour
            const m = transform;
            for (const contour of otherContours) {
                if (contour.length < 2) continue;
                this._pathBuilder.moveTo(
                    contour[0] * m.a + contour[1] * m.c + m.e,
                    contour[0] * m.b + contour[1] * m.d + m.f
                );
                for (let i = 2; i < contour.length; i += 2) {
                    this._pathBuilder.lineTo(
                        contour[i] * m.a + contour[i + 1] * m.c + m.e,
                        contour[i] * m.b + contour[i + 1] * m.d + m.f
                    );
                }
            }
        } else {
            // Copy contours directly
            for (const contour of otherContours) {
                if (contour.length < 2) continue;
                this._pathBuilder.moveTo(contour[0], contour[1]);
                for (let i = 2; i < contour.length; i += 2) {
                    this._pathBuilder.lineTo(contour[i], contour[i + 1]);
                }
            }
        }
    }

    closePath() { this._pathBuilder.closePath(); }
    moveTo(x, y) { this._pathBuilder.moveTo(x, y); }
    lineTo(x, y) { this._pathBuilder.lineTo(x, y); }
    
    quadraticCurveTo(cpx, cpy, x, y) {
        this._pathBuilder.quadraticCurveTo(cpx, cpy, x, y);
    }
    
    bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y) {
        this._pathBuilder.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y);
    }
    
    arc(x, y, radius, startAngle, endAngle, counterclockwise = false) {
        this._pathBuilder.arc(x, y, radius, startAngle, endAngle, counterclockwise);
    }
    
    arcTo(x1, y1, x2, y2, radius) {
        this._pathBuilder.arcTo(x1, y1, x2, y2, radius);
    }
    
    ellipse(x, y, rx, ry, rotation, startAngle, endAngle, counterclockwise = false) {
        this._pathBuilder.ellipse(x, y, rx, ry, rotation, startAngle, endAngle, counterclockwise);
    }
    
    rect(x, y, w, h) { this._pathBuilder.rect(x, y, w, h); }
    roundRect(x, y, w, h, radii) { this._pathBuilder.roundRect(x, y, w, h, radii); }

    /**
     * Parse an SVG path data string.
     */
    _parseSVGPath(d) {
        const tokens = d.match(/[MmLlHhVvCcSsQqTtAaZz][^MmLlHhVvCcSsQqTtAaZz]*/g);
        if (!tokens) return;

        let cx = 0, cy = 0; // Current position
        let cpx = 0, cpy = 0; // Last control point for smooth curves
        let startX = 0, startY = 0;
        let hasCurrent = false;

        const nums = (str) => {
            const matches = str.match(/-?\d+\.?\d*(?:e[-+]?\d+)?/gi);
            return matches ? matches.map(Number) : [];
        };

        for (const token of tokens) {
            const cmd = token[0];
            const n = nums(token);
            let i = 0;
            const abs = cmd === cmd.toUpperCase();

            switch (cmd.toUpperCase()) {
                case 'M': {
                    while (i < n.length) {
                        let x = n[i++], y = n[i++];
                        if (!abs) { x += cx; y += cy; }
                        if (!hasCurrent) {
                            this._pathBuilder.moveTo(x, y);
                            hasCurrent = true;
                        } else {
                            this._pathBuilder.lineTo(x, y);
                        }
                        cx = startX = x;
                        cy = startY = y;
                    }
                    break;
                }
                case 'L': {
                    while (i < n.length) {
                        let x = n[i++], y = n[i++];
                        if (!abs) { x += cx; y += cy; }
                        this._pathBuilder.lineTo(x, y);
                        cx = x; cy = y;
                    }
                    break;
                }
                case 'H': {
                    while (i < n.length) {
                        let x = n[i++];
                        if (!abs) x += cx;
                        this._pathBuilder.lineTo(x, cy);
                        cx = x;
                    }
                    break;
                }
                case 'V': {
                    while (i < n.length) {
                        let y = n[i++];
                        if (!abs) y += cy;
                        this._pathBuilder.lineTo(cx, y);
                        cy = y;
                    }
                    break;
                }
                case 'C': {
                    while (i < n.length) {
                        let x1 = n[i++], y1 = n[i++], x2 = n[i++], y2 = n[i++], x = n[i++], y = n[i++];
                        if (!abs) { x1 += cx; y1 += cy; x2 += cx; y2 += cy; x += cx; y += cy; }
                        this._pathBuilder.bezierCurveTo(x1, y1, x2, y2, x, y);
                        cpx = x2; cpy = y2;
                        cx = x; cy = y;
                    }
                    break;
                }
                case 'S': {
                    while (i < n.length) {
                        let x2 = n[i++], y2 = n[i++], x = n[i++], y = n[i++];
                        if (!abs) { x2 += cx; y2 += cy; x += cx; y += cy; }
                        let x1 = 2 * cx - cpx, y1 = 2 * cy - cpy;
                        this._pathBuilder.bezierCurveTo(x1, y1, x2, y2, x, y);
                        cpx = x2; cpy = y2;
                        cx = x; cy = y;
                    }
                    break;
                }
                case 'Q': {
                    while (i < n.length) {
                        let x1 = n[i++], y1 = n[i++], x = n[i++], y = n[i++];
                        if (!abs) { x1 += cx; y1 += cy; x += cx; y += cy; }
                        this._pathBuilder.quadraticCurveTo(x1, y1, x, y);
                        cpx = x1; cpy = y1;
                        cx = x; cy = y;
                    }
                    break;
                }
                case 'T': {
                    while (i < n.length) {
                        let x = n[i++], y = n[i++];
                        if (!abs) { x += cx; y += cy; }
                        let x1 = 2 * cx - cpx, y1 = 2 * cy - cpy;
                        this._pathBuilder.quadraticCurveTo(x1, y1, x, y);
                        cpx = x1; cpy = y1;
                        cx = x; cy = y;
                    }
                    break;
                }
                case 'A': {
                    while (i < n.length) {
                        let rx = n[i++], ry = n[i++], rot = n[i++];
                        let largeArc = n[i++], sweep = n[i++];
                        let x = n[i++], y = n[i++];
                        if (!abs) { x += cx; y += cy; }
                        
                        if (rx === 0 || ry === 0) {
                            this._pathBuilder.lineTo(x, y);
                        } else {
                            this._arcToBezier(cx, cy, rx, ry, rot, largeArc !== 0, sweep !== 0, x, y);
                        }
                        
                        cx = x; cy = y;
                    }
                    break;
                }
                case 'Z': {
                    this._pathBuilder.closePath();
                    cx = startX;
                    cy = startY;
                    break;
                }
            }
        }
    }

    /**
     * Convert SVG arc to cubic bezier curves.
     */
    _arcToBezier(x0, y0, rx, ry, phi, fA, fS, x1, y1) {
        phi = phi * Math.PI / 180;
        const cosP = Math.cos(phi), sinP = Math.sin(phi);
        
        // Step 1: Compute (x1', y1')
        const dx = (x0 - x1) / 2, dy = (y0 - y1) / 2;
        const x1p = cosP * dx + sinP * dy;
        const y1p = -sinP * dx + cosP * dy;
        
        // Step 2: Compute (cx', cy')
        let lambda = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry);
        if (lambda > 1) {
            const s = Math.sqrt(lambda);
            rx *= s;
            ry *= s;
            lambda = 1;
        }
        
        const s = Math.sqrt(Math.max(0, (rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p) /
            (rx * rx * y1p * y1p + ry * ry * x1p * x1p)));
        const cxp = s * (rx * y1p) / ry * (fA === fS ? -1 : 1);
        const cyp = s * (-(ry * x1p) / rx) * (fA === fS ? -1 : 1);
        
        // Step 3: Compute (cx, cy)
        const cx = cosP * cxp - sinP * cyp + (x0 + x1) / 2;
        const cy = sinP * cxp + cosP * cyp + (y0 + y1) / 2;
        
        // Step 4: Compute start and end angles
        const ux = (x1p - cxp) / rx, uy = (y1p - cyp) / ry;
        const vx = (-x1p - cxp) / rx, vy = (-y1p - cyp) / ry;
        
        let startAngle = Math.atan2(uy, ux);
        let deltaAngle = Math.atan2(vy, vx) - Math.atan2(uy, ux);
        
        if (!fS && deltaAngle > 0) deltaAngle -= 2 * Math.PI;
        if (fS && deltaAngle < 0) deltaAngle += 2 * Math.PI;
        
        // Approximate with bezier curves
        const segments = Math.ceil(Math.abs(deltaAngle) / (Math.PI / 2));
        const eta1 = Math.atan2(uy, ux);
        const cosEta = Math.cos(eta1), sinEta = Math.sin(eta1);
        const ep = 0.551784 * Math.tan(deltaAngle / (segments * 2));
        
        // Use arc flattening from math.js
        const out = [];
        flattenArc(cx, cy, rx, ry, startAngle, startAngle + deltaAngle, phi, deltaAngle < 0, out);
        
        if (out.length >= 2) {
            this._pathBuilder.moveTo(x0, y0);
            for (let i = 0; i < out.length; i += 2) {
                this._pathBuilder.lineTo(out[i], out[i + 1]);
            }
        }
    }

    // For internal use - get contours
    getContours() {
        return this._pathBuilder.getContours();
    }
}

export { Path2D };
