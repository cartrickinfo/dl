/**
 * Text rendering - fillText, strokeText, measureText.
 * Uses a glyph atlas for efficient text rendering.
 */

import { matrixToArray } from '../tools/math.js';

/**
 * Measure text using a hidden canvas context.
 */
export function measureText(text, font) {
    text = String(text);

    // Use a persistent offscreen canvas for measurements
    if (!measureText._canvas) {
        measureText._canvas = document.createElement('canvas');
        measureText._canvas.width = 1;
        measureText._canvas.height = 1;
        measureText._ctx = measureText._canvas.getContext('2d');
    }

    measureText._ctx.font = font;
    return measureText._ctx.measureText(text);
}

/**
 * Render text using the glyph atlas.
 * Now supports letterSpacing.
 */
export function fillText(renderer, glyphAtlas, text, x, y, maxWidth, font, textAlign, textBaseline,
                         direction, fillStyle, globalAlpha, currentTransform, letterSpacing) {
    text = String(text);
    if (text.length === 0) return;

    // Parse fill color
    let r = 0, g = 0, b = 0, a = 1;
    if (typeof fillStyle === 'string') {
        const parsed = parseColorFast(fillStyle);
        if (parsed) {
            r = parsed[0]; g = parsed[1]; b = parsed[2]; a = parsed[3];
        }
    }
    a *= globalAlpha;

    const metrics = measureText(text, font);
    const chars = [...text]; // Handle surrogate pairs

    // Calculate horizontal offset based on textAlign
    let offsetX = 0;
    switch (textAlign) {
        case 'end':
            offsetX = direction === 'rtl' ? 0 : -metrics.width;
            break;
        case 'start':
            offsetX = direction === 'rtl' ? -metrics.width : 0;
            break;
        case 'center':
            offsetX = -metrics.width / 2;
            break;
        case 'right':
            offsetX = -metrics.width;
            break;
        // 'left' = 0
    }

    // Calculate vertical offset based on textBaseline
    let offsetY = 0;
    const fontSize = parseFontSize(font);
    switch (textBaseline) {
        case 'top':
            offsetY = fontSize * 0.8;
            break;
        case 'hanging':
            offsetY = fontSize * 0.9;
            break;
        case 'middle':
            offsetY = fontSize * 0.35;
            break;
        case 'alphabetic':
            offsetY = 0;
            break;
        case 'ideographic':
            offsetY = -fontSize * 0.15;
            break;
        case 'bottom':
            offsetY = -fontSize * 0.2;
            break;
    }

    // Parse letterSpacing
    let extraSpace = 0;
    if (letterSpacing && letterSpacing !== '0px') {
        const match = String(letterSpacing).match(/^(-?\d+\.?\d*)/);
        if (match) extraSpace = parseFloat(match[1]);
    }

    const mtx = matrixToArray(currentTransform);
    let cursorX = x + offsetX;
    const baseY = y + offsetY;

    // Apply maxWidth scaling if specified
    let scaleX = 1;
    if (maxWidth !== undefined && maxWidth > 0 && metrics.width > maxWidth) {
        scaleX = maxWidth / metrics.width;
    }

    for (let i = 0; i < chars.length; i++) {
        const char = chars[i];
        
        if (char === ' ') {
            // Use actual space width from glyph atlas or approximate
            const spaceGlyph = glyphAtlas.getGlyph(' ', font);
            cursorX += (spaceGlyph ? spaceGlyph.advance : fontSize * 0.3) * scaleX;
            continue;
        }

        const glyph = glyphAtlas.getGlyph(char, font);
        if (!glyph) {
            cursorX += fontSize * 0.5 * scaleX;
            continue;
        }

        const gx = cursorX;
        const gy = baseY - glyph.ascent;

        // Draw glyph quad with proper color tint
        renderer.drawTexturedQuad(
            gx, gy,
            gx + glyph.w * scaleX, gy,
            gx, gy + glyph.h,
            gx + glyph.w * scaleX, gy + glyph.h,
            glyph.u1, glyph.v1,
            glyph.u2, glyph.v2,
            r, g, b, a,
            mtx,
            glyphAtlas.texture
        );

        cursorX += (glyph.advance + extraSpace) * scaleX;
    }

    // Sync glyph atlas texture after all glyphs are rasterized
    glyphAtlas.sync();
}

/**
 * Parse font size from font string (approximate).
 */
export function parseFontSize(font) {
    const match = font.match(/(\d+(?:\.\d+)?)\s*(px|pt|em|rem|%)/);
    if (match) {
        const val = parseFloat(match[1]);
        const unit = match[2];
        switch (unit) {
            case 'px': return val;
            case 'pt': return val * 1.333;
            case 'em': return val * 16;
            case 'rem': return val * 16;
            default: return val;
        }
    }
    return 10; // Default
}

/**
 * Fast color parser for text (simplified).
 */
function parseColorFast(str) {
    str = String(str).trim().toLowerCase();

    // Named colors cache
    const named = {
        black: [0, 0, 0, 1], white: [1, 1, 1, 1], red: [1, 0, 0, 1],
        green: [0, 0.5, 0, 1], blue: [0, 0, 1, 1], yellow: [1, 1, 0, 1],
        cyan: [0, 1, 1, 1], magenta: [1, 0, 1, 1], transparent: [0, 0, 0, 0]
    };
    if (named[str]) return named[str];

    // Hex
    if (str[0] === '#') {
        const hex = str.slice(1);
        if (hex.length === 3) {
            return [
                parseInt(hex[0] + hex[0], 16) / 255,
                parseInt(hex[1] + hex[1], 16) / 255,
                parseInt(hex[2] + hex[2], 16) / 255,
                1
            ];
        }
        if (hex.length === 6) {
            const num = parseInt(hex, 16);
            return [((num >> 16) & 255) / 255, ((num >> 8) & 255) / 255, (num & 255) / 255, 1];
        }
        if (hex.length === 8) {
            const num = parseInt(hex, 16);
            return [((num >> 24) & 255) / 255, ((num >> 16) & 255) / 255, ((num >> 8) & 255) / 255, (num & 255) / 255];
        }
    }

    // rgb/rgba
    const rgbMatch = str.match(/rgba?\(([^)]+)\)/);
    if (rgbMatch) {
        const parts = rgbMatch[1].split(',').map(s => parseFloat(s.trim()));
        if (parts.length >= 3) {
            return [parts[0] / 255, parts[1] / 255, parts[2] / 255, parts[3] !== undefined ? parts[3] : 1];
        }
    }

    // hsl/hsla
    const hslMatch = str.match(/hsla?\(([^)]+)\)/);
    if (hslMatch) {
        const parts = hslMatch[1].split(',').map(s => s.trim());
        if (parts.length >= 3) {
            const h = parseFloat(parts[0]);
            const s = parseFloat(parts[1]) / 100;
            const l = parseFloat(parts[2]) / 100;
            const a = parts[3] !== undefined ? parseFloat(parts[3]) : 1;
            const [r, g, b] = hslToRgb(h, s, l);
            return [r, g, b, a];
        }
    }

    return [0, 0, 0, 1]; // Default black
}

function hslToRgb(h, s, l) {
    if (s === 0) return [l, l, l];
    h = ((h % 360) + 360) % 360;
    const c = (1 - Math.abs(2 * l - 1)) * s;
    const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
    const m = l - c / 2;
    let r, g, b;

    if (h < 60) [r, g, b] = [c, x, 0];
    else if (h < 120) [r, g, b] = [x, c, 0];
    else if (h < 180) [r, g, b] = [0, c, x];
    else if (h < 240) [r, g, b] = [0, x, c];
    else if (h < 300) [r, g, b] = [x, 0, c];
    else [r, g, b] = [c, 0, x];

    return [r + m, g + m, b + m];
}
