/**
 * Path building - all Canvas 2D path methods.
 * Uses adaptive subdivision for curves and proper arc handling.
 */

import {
    flattenCubicBezier,
    flattenQuadraticBezier,
    flattenArc
} from '../tools/math.js';

/** Path command types */
const MOVE = 0;
const LINE = 1;
const CLOSE = 2;

class PathBuilder {
    constructor() {
        this.reset();
    }

    reset() {
        this.commands = []; // {type, x, y} flattened to x,y pairs for lines
        this.points = [];   // Flat array of [x, y, x, y, ...]
        this.contours = []; // Array of contour start indices
        this.currentX = 0;
        this.currentY = 0;
        this.startX = 0;
        this.startY = 0;
        this._hasCurrentPoint = false;
    }

    get hasCurrentPoint() {
        return this._hasCurrentPoint;
    }

    moveTo(x, y) {
        x = Number(x); y = Number(y);
        if (isNaN(x) || isNaN(y)) return;
        if (this.points.length > 0 && this.contours.length === 0) {
            this.contours.push(0);
        }
        this.contours.push(this.points.length);
        this.points.push(x, y);
        this.currentX = this.startX = x;
        this.currentY = this.startY = y;
        this._hasCurrentPoint = true;
    }

    lineTo(x, y) {
        x = Number(x); y = Number(y);
        if (isNaN(x) || isNaN(y)) return;
        if (!this._hasCurrentPoint) {
            this.moveTo(x, y);
            return;
        }
        this.points.push(x, y);
        this.currentX = x;
        this.currentY = y;
    }

    closePath() {
        if (!this._hasCurrentPoint) return;
        if (this.currentX !== this.startX || this.currentY !== this.startY) {
            this.points.push(this.startX, this.startY);
            this.currentX = this.startX;
            this.currentY = this.startY;
        }
        // Mark contour as closed
        if (this.contours.length > 0) {
            const startIdx = this.contours[this.contours.length - 1];
            this.points._closed = this.points._closed || new Set();
            this.points._closed.add(startIdx);
        }
    }

    quadraticCurveTo(cpx, cpy, x, y) {
        cpx = Number(cpx); cpy = Number(cpy);
        x = Number(x); y = Number(y);
        if ([cpx, cpy, x, y].some(isNaN)) return;

        const p0x = this._hasCurrentPoint ? this.currentX : cpx;
        const p0y = this._hasCurrentPoint ? this.currentY : cpy;
        if (!this._hasCurrentPoint) this.moveTo(p0x, p0y);

        const out = [];
        flattenQuadraticBezier(p0x, p0y, cpx, cpy, x, y, out);
        for (let i = 0; i < out.length; i += 2) {
            this.points.push(out[i], out[i + 1]);
        }
        this.currentX = x;
        this.currentY = y;
    }

    bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y) {
        cp1x = Number(cp1x); cp1y = Number(cp1y);
        cp2x = Number(cp2x); cp2y = Number(cp2y);
        x = Number(x); y = Number(y);
        if ([cp1x, cp1y, cp2x, cp2y, x, y].some(isNaN)) return;

        const p0x = this._hasCurrentPoint ? this.currentX : cp1x;
        const p0y = this._hasCurrentPoint ? this.currentY : cp1y;
        if (!this._hasCurrentPoint) this.moveTo(p0x, p0y);

        const out = [];
        flattenCubicBezier(p0x, p0y, cp1x, cp1y, cp2x, cp2y, x, y, out);
        for (let i = 0; i < out.length; i += 2) {
            this.points.push(out[i], out[i + 1]);
        }
        this.currentX = x;
        this.currentY = y;
    }

    arc(x, y, radius, startAngle, endAngle, counterclockwise = false) {
        x = Number(x); y = Number(y); radius = Number(radius);
        startAngle = Number(startAngle); endAngle = Number(endAngle);
        if ([x, y, radius, startAngle, endAngle].some(isNaN)) return;
        if (radius < 0) throw new Error('IndexSizeError: radius cannot be negative');
        if (radius === 0) {
            this.lineTo(x, y);
            return;
        }

        const firstX = x + Math.cos(startAngle) * radius;
        const firstY = y + Math.sin(startAngle) * radius;

        if (!this._hasCurrentPoint) {
            this.moveTo(firstX, firstY);
        } else {
            const dx = Math.abs(this.currentX - firstX);
            const dy = Math.abs(this.currentY - firstY);
            if (dx > 1e-6 || dy > 1e-6) {
                this.lineTo(firstX, firstY);
            }
        }

        const out = [];
        // Full circle arc
        flattenArc(x, y, radius, radius, startAngle, endAngle, 0, counterclockwise, out);
        for (let i = 0; i < out.length; i += 2) {
            this.points.push(out[i], out[i + 1]);
        }
        if (out.length >= 2) {
            this.currentX = out[out.length - 2];
            this.currentY = out[out.length - 1];
        }
    }

    arcTo(x1, y1, x2, y2, radius) {
        x1 = Number(x1); y1 = Number(y1);
        x2 = Number(x2); y2 = Number(y2);
        radius = Number(radius);
        if ([x1, y1, x2, y2, radius].some(isNaN)) return;
        if (radius < 0) throw new Error('IndexSizeError: radius cannot be negative');
        if (!this._hasCurrentPoint) {
            this.moveTo(x1, y1);
            return;
        }
        if (radius === 0) {
            this.lineTo(x1, y1);
            return;
        }

        const { currentX: x0, currentY: y0 } = this;

        const dx0 = x0 - x1, dy0 = y0 - y1;
        const dx1 = x2 - x1, dy1 = y2 - y1;
        const len0 = Math.hypot(dx0, dy0);
        const len1 = Math.hypot(dx1, dy1);

        if (len0 === 0 || len1 === 0) {
            this.lineTo(x1, y1);
            return;
        }

        const ux0 = dx0 / len0, uy0 = dy0 / len0;
        const ux1 = dx1 / len1, uy1 = dy1 / len1;
        const dot = ux0 * ux1 + uy0 * uy1;

        // Nearly straight lines
        if (Math.abs(dot) > 0.9999) {
            this.lineTo(x1, y1);
            return;
        }

        const angle = Math.acos(Math.max(-1, Math.min(1, dot)));
        const dist = radius / Math.tan(angle / 2);

        // Tangent points
        const t1x = x1 + ux0 * dist;
        const t1y = y1 + uy0 * dist;
        const t2x = x1 + ux1 * dist;
        const t2y = y1 + uy1 * dist;

        // Arc center
        const bisectLen = radius / Math.sin(angle / 2);
        const bx = ux0 + ux1;
        const by = uy0 + uy1;
        const bLen = Math.hypot(bx, by);
        if (bLen === 0) {
            this.lineTo(x1, y1);
            return;
        }

        const cx = x1 + (bx / bLen) * bisectLen;
        const cy = y1 + (by / bLen) * bisectLen;

        const startAngle = Math.atan2(t1y - cy, t1x - cx);
        const endAngle = Math.atan2(t2y - cy, t2x - cx);
        const ccw = (ux0 * uy1 - uy0 * ux1) > 0;

        this.lineTo(t1x, t1y);
        this._arcDirect(cx, cy, radius, startAngle, endAngle, ccw);
    }

    _arcDirect(cx, cy, r, sa, ea, ccw) {
        const out = [];
        flattenArc(cx, cy, r, r, sa, ea, 0, ccw, out);
        for (let i = 0; i < out.length; i += 2) {
            this.points.push(out[i], out[i + 1]);
        }
        if (out.length >= 2) {
            this.currentX = out[out.length - 2];
            this.currentY = out[out.length - 1];
        }
    }

    ellipse(x, y, rx, ry, rotation, startAngle, endAngle, counterclockwise = false) {
        x = Number(x); y = Number(y); rx = Number(rx); ry = Number(ry);
        rotation = Number(rotation); startAngle = Number(startAngle); endAngle = Number(endAngle);
        if ([x, y, rx, ry, rotation, startAngle, endAngle].some(isNaN)) return;
        if (rx < 0 || ry < 0) throw new Error('IndexSizeError: radius cannot be negative');

        const cosR = Math.cos(rotation);
        const sinR = Math.sin(rotation);
        const firstX = x + (Math.cos(startAngle) * rx * cosR - Math.sin(startAngle) * ry * sinR);
        const firstY = y + (Math.cos(startAngle) * rx * sinR + Math.sin(startAngle) * ry * cosR);

        if (!this._hasCurrentPoint) {
            this.moveTo(firstX, firstY);
        } else {
            this.lineTo(firstX, firstY);
        }

        const out = [];
        flattenArc(x, y, rx, ry, startAngle, endAngle, rotation, counterclockwise, out);
        for (let i = 0; i < out.length; i += 2) {
            this.points.push(out[i], out[i + 1]);
        }
        if (out.length >= 2) {
            this.currentX = out[out.length - 2];
            this.currentY = out[out.length - 1];
        }
    }

    rect(x, y, w, h) {
        x = Number(x); y = Number(y); w = Number(w); h = Number(h);
        if ([x, y, w, h].some(isNaN)) return;
        this.moveTo(x, y);
        this.lineTo(x + w, y);
        this.lineTo(x + w, y + h);
        this.lineTo(x, y + h);
        this.closePath();
    }

    roundRect(x, y, w, h, radii) {
        x = Number(x); y = Number(y); w = Number(w); h = Number(h);
        if ([x, y, w, h].some(isNaN)) return;

        let tlr, trr, brr, blr;
        radii = this._normalizeRadii(radii);
        [tlr, trr, brr, blr] = radii;

        const maxR = Math.min(Math.abs(w), Math.abs(h)) / 2;
        tlr = Math.min(tlr, maxR);
        trr = Math.min(trr, maxR);
        brr = Math.min(brr, maxR);
        blr = Math.min(blr, maxR);

        this.moveTo(x + tlr, y);
        this.lineTo(x + w - trr, y);
        if (trr > 0) this.arcTo(x + w, y, x + w, y + trr, trr);
        this.lineTo(x + w, y + h - brr);
        if (brr > 0) this.arcTo(x + w, y + h, x + w - brr, y + h, brr);
        this.lineTo(x + blr, y + h);
        if (blr > 0) this.arcTo(x, y + h, x, y + h - blr, blr);
        this.lineTo(x, y + tlr);
        if (tlr > 0) this.arcTo(x, y, x + tlr, y, tlr);
        this.closePath();
    }

    _normalizeRadii(radii) {
        if (typeof radii === 'number') {
            return [Math.abs(radii), Math.abs(radii), Math.abs(radii), Math.abs(radii)];
        }
        if (!Array.isArray(radii)) return [0, 0, 0, 0];
        const r = radii.map(v => Math.abs(Number(v) || 0));
        if (r.length === 1) return [r[0], r[0], r[0], r[0]];
        if (r.length === 2) return [r[0], r[1], r[0], r[1]];
        if (r.length === 3) return [r[0], r[1], r[2], r[1]];
        return [r[0], r[1], r[2], r[3]];
    }

    /** Get flat contour arrays for triangulation */
    getContours() {
        const contours = [];
        const pts = this.points;
        if (pts.length === 0) return contours;

        // Build contours from contour start indices
        const starts = [...this.contours, pts.length];
        for (let i = 0; i < starts.length - 1; i++) {
            const start = starts[i];
            const end = starts[i + 1];
            if (end - start >= 4) { // At least 2 points
                contours.push(pts.slice(start, end));
            }
        }

        // If no explicit contours, treat all points as one contour
        if (contours.length === 0 && pts.length >= 4) {
            contours.push(pts.slice());
        }

        return contours;
    }

    /** Convert path to flat vertices for stroke rendering */
    getStrokeVertices(width, cap, join, miterLimit) {
        const contours = this.getContours();
        const result = [];
        const halfWidth = width / 2;

        for (const contour of contours) {
            if (contour.length < 4) continue;
            this._strokeContour(contour, halfWidth, cap, join, miterLimit, result);
        }

        return result;
    }

    _strokeContour(contour, hw, cap, join, miterLimit, out) {
        const count = contour.length / 2;
        if (count < 2) return;

        const isClosed = this._isContourClosed(contour);

        // Generate stroke geometry for each segment
        for (let i = 0; i < count - 1; i++) {
            const x1 = contour[i * 2], y1 = contour[i * 2 + 1];
            const x2 = contour[(i + 1) * 2], y2 = contour[(i + 1) * 2 + 1];

            const dx = x2 - x1;
            const dy = y2 - y1;
            const len = Math.hypot(dx, dy);
            if (len < 0.001) continue;

            const nx = -dy / len * hw;
            const ny = dx / len * hw;

            // Quad for this segment
            out.push(
                x1 + nx, y1 + ny,
                x1 - nx, y1 - ny,
                x2 + nx, y2 + ny,
                x1 - nx, y1 - ny,
                x2 - nx, y2 - ny,
                x2 + nx, y2 + ny
            );

            // Line caps for end segments
            if (!isClosed) {
                if (i === 0) this._addCap(x1, y1, dx, dy, hw, cap, out, true);
                if (i === count - 2) this._addCap(x2, y2, dx, dy, hw, cap, out, false);
            }
        }
    }

    _isContourClosed(contour) {
        if (contour.length < 4) return false;
        const x1 = contour[0], y1 = contour[1];
        const x2 = contour[contour.length - 2], y2 = contour[contour.length - 1];
        return Math.abs(x1 - x2) < 1e-4 && Math.abs(y1 - y2) < 1e-4;
    }

    _addCap(x, y, dx, dy, hw, cap, out, isStart) {
        if (cap === 'butt') return;

        const len = Math.hypot(dx, dy);
        if (len < 0.001) return;

        const nx = -dy / len;
        const ny = dx / len;

        if (cap === 'square') {
            const ex = isStart ? -dx / len * hw : dx / len * hw;
            const ey = isStart ? -dy / len * hw : dy / len * hw;
            const sx = x + ex;
            const sy = y + ey;
            const sx2 = sx + nx * hw;
            const sy2 = sy + ny * hw;
            const sx3 = sx - nx * hw;
            const sy3 = sy - ny * hw;

            out.push(
                x + nx * hw, y + ny * hw,
                x - nx * hw, y - ny * hw,
                sx2, sy2,
                x - nx * hw, y - ny * hw,
                sx3, sy3,
                sx2, sy2
            );
        } else if (cap === 'round') {
            // Semicircle cap - approximate with triangles
            const steps = 8;
            const angle = Math.atan2(ny, nx);
            const startA = angle + Math.PI / 2;
            const endA = angle - Math.PI / 2;
            const dir = isStart ? 1 : -1;

            for (let i = 0; i < steps; i++) {
                const a1 = startA + (endA - startA) * (i / steps) * dir;
                const a2 = startA + (endA - startA) * ((i + 1) / steps) * dir;
                out.push(
                    x, y,
                    x + Math.cos(a1) * hw, y + Math.sin(a1) * hw,
                    x + Math.cos(a2) * hw, y + Math.sin(a2) * hw
                );
            }
        }
    }
}

export { PathBuilder, MOVE, LINE, CLOSE };
