/**
 * Gradient classes with built-in color interpolation.
 * No external dependencies - all color math is handled internally.
 */

import ColorParser from '../tools/ColorParser.js';

// Shared color parser instance
const colorParser = new ColorParser();

// Gradient texture resolution
const GRAD_TEXTURE_SIZE = 256;

/** Base gradient class */
class WebGLGradient {
    constructor() {
        this._stops = [];
        this._texture = null;
        this._needsUpdate = true;
    }

    addColorStop(offset, color) {
        offset = Number(offset);
        if (isNaN(offset) || offset < 0 || offset > 1) {
            throw new Error('IndexSizeError: color stop offset must be between 0 and 1');
        }
        this._stops.push({ offset, color: String(color) });
        this._stops.sort((a, b) => a.offset - b.offset);
        this._needsUpdate = true;
        this._texture = null;
    }

    /** Build gradient texture - called internally by the renderer */
    _getTexture(gl) {
        if (this._texture && !this._needsUpdate) {
            return this._texture;
        }

        if (this._stops.length === 0) {
            return null;
        }

        // Build gradient pixel data
        const data = new Uint8Array(GRAD_TEXTURE_SIZE * 4);

        for (let i = 0; i < GRAD_TEXTURE_SIZE; i++) {
            const t = i / (GRAD_TEXTURE_SIZE - 1);
            const [r, g, b, a] = this._colorAt(t);
            data[i * 4] = Math.round(r * 255);
            data[i * 4 + 1] = Math.round(g * 255);
            data[i * 4 + 2] = Math.round(b * 255);
            data[i * 4 + 3] = Math.round(a * 255);
        }

        // Create/update texture
        if (!this._texture) {
            this._texture = gl.createTexture();
        }

        gl.bindTexture(gl.TEXTURE_2D, this._texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, GRAD_TEXTURE_SIZE, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);

        this._needsUpdate = false;
        return this._texture;
    }

    /** Get color at position t [0,1] */
    _colorAt(t) {
        const stops = this._stops;
        if (stops.length === 0) return [0, 0, 0, 1];
        if (stops.length === 1) return colorParser.parse(stops[0].color);

        // Find surrounding stops
        let before = stops[0];
        let after = stops[stops.length - 1];

        for (let i = 0; i < stops.length - 1; i++) {
            if (t >= stops[i].offset && t <= stops[i + 1].offset) {
                before = stops[i];
                after = stops[i + 1];
                break;
            }
        }

        const c1 = colorParser.parse(before.color);
        const c2 = colorParser.parse(after.color);

        if (before === after || before.offset === after.offset) {
            return c1;
        }

        const f = (t - before.offset) / (after.offset - before.offset);
        return [
            c1[0] + (c2[0] - c1[0]) * f,
            c1[1] + (c2[1] - c1[1]) * f,
            c1[2] + (c2[2] - c1[2]) * f,
            c1[3] + (c2[3] - c1[3]) * f
        ];
    }

    /** Release GPU resources */
    dispose(gl) {
        if (this._texture) {
            gl.deleteTexture(this._texture);
            this._texture = null;
        }
    }
}

/** Linear gradient */
class WebGLLinearGradient extends WebGLGradient {
    constructor(x0, y0, x1, y1) {
        super();
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1;
    }
}

/** Radial gradient */
class WebGLRadialGradient extends WebGLGradient {
    constructor(x0, y0, r0, x1, y1, r1) {
        super();
        this.x0 = x0;
        this.y0 = y0;
        this.r0 = r0;
        this.x1 = x1;
        this.y1 = y1;
        this.r1 = r1;
    }
}

/** Conic gradient */
class WebGLConicGradient extends WebGLGradient {
    constructor(angle, x, y) {
        super();
        this.angle = angle;
        this.x = x;
        this.y = y;
    }
}

/**
 * WebGLPattern - CanvasPattern equivalent for pattern fills.
 */
class WebGLPattern {
    constructor(image, repetition) {
        this.image = image;
        this.repetition = repetition || 'repeat';
        
        // Validate repetition
        const valid = ['repeat', 'repeat-x', 'repeat-y', 'no-repeat'];
        if (!valid.includes(this.repetition)) {
            this.repetition = 'repeat';
        }
        
        this._texture = null;
        this._needsUpdate = true;
        this._width = 0;
        this._height = 0;
        
        if (image) {
            this._width = image.naturalWidth || image.width || 0;
            this._height = image.naturalHeight || image.height || 0;
        }
    }

    setTransform(transform) {
        // CanvasPattern.setTransform() - sets the transform matrix for the pattern
        this._transform = transform;
    }

    /** Build texture from image */
    _getTexture(gl) {
        if (this._texture && !this._needsUpdate) {
            return this._texture;
        }

        if (!this.image) return null;

        if (!this._texture) {
            this._texture = gl.createTexture();
        }

        const repeatS = (this.repetition === 'repeat' || this.repetition === 'repeat-x');
        const repeatT = (this.repetition === 'repeat' || this.repetition === 'repeat-y');

        gl.bindTexture(gl.TEXTURE_2D, this._texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, repeatS ? gl.REPEAT : gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, repeatT ? gl.REPEAT : gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        
        try {
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.image);
            this._needsUpdate = false;
        } catch (e) {
            return null;
        }

        this._width = this.image.naturalWidth || this.image.width || this._width;
        this._height = this.image.naturalHeight || this.image.height || this._height;

        return this._texture;
    }

    dispose(gl) {
        if (this._texture) {
            gl.deleteTexture(this._texture);
            this._texture = null;
        }
    }
}

export { WebGLGradient, WebGLLinearGradient, WebGLRadialGradient, WebGLConicGradient, WebGLPattern, GRAD_TEXTURE_SIZE };
