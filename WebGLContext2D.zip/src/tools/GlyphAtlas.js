/**
 * GlyphAtlas - Rasterizes text glyphs onto a texture atlas for fast rendering.
 * Uses a hidden 2D canvas to render text, then uploads to a WebGL texture.
 */
class GlyphAtlas {

    constructor(gl, size = 2048) {
        this.gl = gl;
        this.size = size;
        this.canvas = document.createElement('canvas');
        this.canvas.width = size;
        this.canvas.height = size;
        this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
        this.ctx.clearRect(0, 0, size, size);

        // Packing state (simple shelf packing)
        this.currentShelfY = 0;
        this.currentShelfHeight = 0;
        this.currentX = 0;

        // Glyph cache: key -> {x, y, w, h, u1, v1, u2, v2, advance}
        this.glyphs = new Map();

        // Create WebGL texture
        this.texture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, this.texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, size, size, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);

        this._dirty = false;
    }

    /** Get or create glyph info for a character */
    getGlyph(char, font) {
        const key = font + '|' + char;
        if (this.glyphs.has(key)) {
            return this.glyphs.get(key);
        }
        return this._rasterize(char, font, key);
    }

    /** Rasterize a single glyph onto the atlas */
    _rasterize(char, font, key) {
        const ctx = this.ctx;
        ctx.font = font;

        const metrics = ctx.measureText(char);
        const w = Math.ceil(metrics.width) + 2; // 1px padding each side
        const h = Math.ceil(
            (metrics.actualBoundingBoxAscent || 10) +
            (metrics.actualBoundingBoxDescent || 2)
        ) + 2;

        // Check if we need a new shelf
        if (this.currentX + w > this.size) {
            this.currentShelfY += this.currentShelfHeight;
            this.currentShelfHeight = 0;
            this.currentX = 0;
        }

        // Check if atlas is full
        if (this.currentShelfY + h > this.size) {
            // Atlas full - clear and start over (simple strategy)
            this._clear();
            return this._rasterize(char, font, key);
        }

        // Draw glyph
        ctx.fillStyle = '#FFFFFF';
        ctx.font = font;
        ctx.textBaseline = 'alphabetic';
        ctx.fillText(char, this.currentX + 1, this.currentShelfY + (metrics.actualBoundingBoxAscent || 10) + 1);

        // Calculate UV coordinates
        const u1 = this.currentX / this.size;
        const v1 = this.currentShelfY / this.size;
        const u2 = (this.currentX + w) / this.size;
        const v2 = (this.currentShelfY + h) / this.size;

        const glyph = {
            x: this.currentX,
            y: this.currentShelfY,
            w, h,
            u1, v1, u2, v2,
            advance: metrics.width,
            ascent: metrics.actualBoundingBoxAscent || 10,
            descent: metrics.actualBoundingBoxDescent || 2
        };

        this.glyphs.set(key, glyph);

        // Advance packing cursor
        this.currentX += w + 1; // 1px gap
        this.currentShelfHeight = Math.max(this.currentShelfHeight, h + 1);
        this._dirty = true;

        return glyph;
    }

    /** Upload atlas to GPU if dirty */
    sync() {
        if (!this._dirty) return;
        const gl = this.gl;
        gl.bindTexture(gl.TEXTURE_2D, this.texture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this.canvas);
        this._dirty = false;
    }

    /** Clear the atlas */
    _clear() {
        this.ctx.clearRect(0, 0, this.size, this.size);
        this.glyphs.clear();
        this.currentShelfY = 0;
        this.currentShelfHeight = 0;
        this.currentX = 0;
        this._dirty = true;
    }

    /** Dispose GPU resources */
    dispose() {
        this.gl.deleteTexture(this.texture);
        this.glyphs.clear();
    }
}

export default GlyphAtlas;
