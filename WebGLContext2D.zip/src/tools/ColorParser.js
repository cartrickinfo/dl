/**
 * Ultra-fast color parser with LRU cache.
 * Handles hex, rgb, rgba, hsl, hsla, and named colors.
 */

const NAMED_COLORS = {
    black: [0, 0, 0, 1], white: [1, 1, 1, 1], red: [1, 0, 0, 1],
    green: [0, 0.502, 0, 1], blue: [0, 0, 1, 1], yellow: [1, 1, 0, 1],
    cyan: [0, 1, 1, 1], magenta: [1, 0, 1, 1], lime: [0, 1, 0, 1],
    maroon: [0.502, 0, 0, 1], navy: [0, 0, 0.502, 1], olive: [0.502, 0.502, 0, 1],
    purple: [0.502, 0, 0.502, 1], silver: [0.753, 0.753, 0.753, 1],
    gray: [0.502, 0.502, 0.502, 1], grey: [0.502, 0.502, 0.502, 1], teal: [0, 0.502, 0.502, 1],
    aqua: [0, 1, 1, 1], fuchsia: [1, 0, 1, 1], orange: [1, 0.647, 0, 1],
    transparent: [0, 0, 0, 0],
    // Extended colors
    aliceblue: [0.941, 0.973, 1, 1], antiquewhite: [0.98, 0.922, 0.843, 1],
    aquamarine: [0.498, 1, 0.831, 1], azure: [0.941, 1, 1, 1], beige: [0.961, 0.961, 0.863, 1],
    bisque: [1, 0.894, 0.769, 1], blanchedalmond: [1, 0.922, 0.804, 1],
    blueviolet: [0.541, 0.169, 0.886, 1], brown: [0.647, 0.165, 0.165, 1],
    burlywood: [0.871, 0.722, 0.529, 1], cadetblue: [0.373, 0.620, 0.627, 1],
    chartreuse: [0.498, 1, 0, 1], chocolate: [0.824, 0.412, 0.118, 1],
    coral: [1, 0.498, 0.314, 1], cornflowerblue: [0.392, 0.584, 0.929, 1],
    cornsilk: [1, 0.973, 0.863, 1], crimson: [0.863, 0.078, 0.235, 1],
    darkblue: [0, 0, 0.545, 1], darkcyan: [0, 0.545, 0.545, 1],
    darkgoldenrod: [0.722, 0.525, 0.043, 1], darkgray: [0.663, 0.663, 0.663, 1],
    darkgreen: [0, 0.392, 0, 1], darkgrey: [0.663, 0.663, 0.663, 1],
    darkkhaki: [0.741, 0.718, 0.420, 1], darkmagenta: [0.545, 0, 0.545, 1],
    darkolivegreen: [0.333, 0.420, 0.184, 1], darkorange: [1, 0.549, 0, 1],
    darkorchid: [0.600, 0.196, 0.800, 1], darkred: [0.545, 0, 0, 1],
    darksalmon: [0.914, 0.588, 0.478, 1], darkseagreen: [0.561, 0.737, 0.561, 1],
    darkslateblue: [0.282, 0.239, 0.545, 1], darkslategray: [0.184, 0.310, 0.310, 1],
    darkslategrey: [0.184, 0.310, 0.310, 1], darkturquoise: [0, 0.808, 0.820, 1],
    darkviolet: [0.580, 0, 0.827, 1], deeppink: [1, 0.078, 0.576, 1],
    deepskyblue: [0, 0.749, 1, 1], dimgray: [0.412, 0.412, 0.412, 1],
    dimgrey: [0.412, 0.412, 0.412, 1], dodgerblue: [0.118, 0.565, 1, 1],
    firebrick: [0.698, 0.133, 0.133, 1], floralwhite: [1, 0.980, 0.941, 1],
    forestgreen: [0.133, 0.545, 0.133, 1], gainsboro: [0.863, 0.863, 0.863, 1],
    ghostwhite: [0.973, 0.973, 1, 1], gold: [1, 0.843, 0, 1],
    goldenrod: [0.855, 0.647, 0.125, 1], greenyellow: [0.678, 1, 0.184, 1],
    honeydew: [0.941, 1, 0.941, 1], hotpink: [1, 0.412, 0.706, 1],
    indianred: [0.804, 0.361, 0.361, 1], indigo: [0.294, 0, 0.510, 1],
    ivory: [1, 1, 0.941, 1], khaki: [0.941, 0.902, 0.549, 1],
    lavender: [0.902, 0.902, 0.980, 1], lavenderblush: [1, 0.941, 0.961, 1],
    lawngreen: [0.486, 0.988, 0, 1], lemonchiffon: [1, 0.980, 0.804, 1],
    lightblue: [0.678, 0.847, 0.902, 1], lightcoral: [0.941, 0.502, 0.502, 1],
    lightcyan: [0.878, 1, 1, 1], lightgoldenrodyellow: [0.980, 0.980, 0.824, 1],
    lightgray: [0.827, 0.827, 0.827, 1], lightgreen: [0.565, 0.933, 0.565, 1],
    lightgrey: [0.827, 0.827, 0.827, 1], lightpink: [1, 0.714, 0.757, 1],
    lightsalmon: [1, 0.627, 0.478, 1], lightseagreen: [0.125, 0.698, 0.667, 1],
    lightskyblue: [0.529, 0.808, 0.980, 1], lightslategray: [0.467, 0.533, 0.600, 1],
    lightslategrey: [0.467, 0.533, 0.600, 1], lightsteelblue: [0.690, 0.769, 0.871, 1],
    lightyellow: [1, 1, 0.878, 1], limegreen: [0.196, 0.804, 0.196, 1],
    linen: [0.980, 0.941, 0.902, 1], mediumaquamarine: [0.400, 0.804, 0.667, 1],
    mediumblue: [0, 0, 0.804, 1], mediumorchid: [0.729, 0.333, 0.827, 1],
    mediumpurple: [0.576, 0.439, 0.859, 1], mediumseagreen: [0.235, 0.702, 0.443, 1],
    mediumslateblue: [0.482, 0.408, 0.933, 1], mediumspringgreen: [0, 0.980, 0.604, 1],
    mediumturquoise: [0.282, 0.820, 0.800, 1], mediumvioletred: [0.780, 0.082, 0.522, 1],
    midnightblue: [0.098, 0.098, 0.439, 1], mintcream: [0.961, 1, 0.980, 1],
    mistyrose: [1, 0.894, 0.882, 1], moccasin: [1, 0.894, 0.710, 1],
    navajowhite: [1, 0.871, 0.678, 1], oldlace: [0.992, 0.961, 0.902, 1],
    olivedrab: [0.420, 0.557, 0.137, 1], orangered: [1, 0.271, 0, 1],
    orchid: [0.855, 0.439, 0.839, 1], palegoldenrod: [0.933, 0.910, 0.667, 1],
    palegreen: [0.596, 0.984, 0.596, 1], paleturquoise: [0.686, 0.933, 0.933, 1],
    palevioletred: [0.859, 0.439, 0.576, 1], papayawhip: [1, 0.937, 0.835, 1],
    peachpuff: [1, 0.855, 0.725, 1], peru: [0.804, 0.522, 0.247, 1],
    pink: [1, 0.753, 0.796, 1], plum: [0.867, 0.627, 0.867, 1],
    powderblue: [0.690, 0.878, 0.902, 1], rosybrown: [0.737, 0.561, 0.561, 1],
    royalblue: [0.255, 0.412, 0.882, 1], saddlebrown: [0.545, 0.271, 0.075, 1],
    salmon: [0.980, 0.502, 0.447, 1], sandybrown: [0.957, 0.643, 0.376, 1],
    seagreen: [0.180, 0.545, 0.341, 1], seashell: [1, 0.961, 0.933, 1],
    sienna: [0.627, 0.322, 0.176, 1], skyblue: [0.529, 0.808, 0.922, 1],
    slateblue: [0.416, 0.353, 0.804, 1], slategray: [0.439, 0.502, 0.565, 1],
    slategrey: [0.439, 0.502, 0.565, 1], snow: [1, 0.980, 0.980, 1],
    springgreen: [0, 1, 0.498, 1], steelblue: [0.275, 0.510, 0.706, 1],
    tan: [0.824, 0.706, 0.549, 1], thistle: [0.847, 0.749, 0.847, 1],
    tomato: [1, 0.388, 0.278, 1], turquoise: [0.251, 0.878, 0.816, 1],
    violet: [0.933, 0.510, 0.933, 1], wheat: [0.961, 0.871, 0.702, 1],
    whitesmoke: [0.961, 0.961, 0.961, 1], yellowgreen: [0.604, 0.804, 0.196, 1]
};

// Pre-compile regex patterns
const HEX_RE = /^#([0-9a-f]{3,8})$/i;
const RGB_RE = /^rgba?\s*\(\s*([^)]+)\s*\)$/i;
const HSL_RE = /^hsla?\s*\(\s*([^)]+)\s*\)$/i;

class ColorParser {
    constructor(cacheSize = 512) {
        this._cache = new Map();
        this._cacheSize = cacheSize;
    }

    parse(str) {
        str = String(str).trim().toLowerCase();

        if (this._cache.has(str)) {
            return this._cache.get(str);
        }

        const result = this._parseInternal(str);

        // LRU cache management
        if (this._cache.size >= this._cacheSize) {
            const firstKey = this._cache.keys().next().value;
            this._cache.delete(firstKey);
        }
        this._cache.set(str, result);
        return result;
    }

    _parseInternal(str) {
        // 1. Named colors
        if (NAMED_COLORS[str]) return NAMED_COLORS[str];

        // 2. Hex
        const hexMatch = str.match(HEX_RE);
        if (hexMatch) return this._parseHex(hexMatch[1]);

        // 3. RGB/RGBA
        const rgbMatch = str.match(RGB_RE);
        if (rgbMatch) return this._parseRgb(rgbMatch[1]);

        // 4. HSL/HSLA
        const hslMatch = str.match(HSL_RE);
        if (hslMatch) return this._parseHsl(hslMatch[1]);

        // 5. Fallback
        return [0, 0, 0, 1];
    }

    _parseHex(hex) {
        const len = hex.length;
        let r, g, b, a = 1;

        if (len === 3) {
            r = parseInt(hex[0] + hex[0], 16) / 255;
            g = parseInt(hex[1] + hex[1], 16) / 255;
            b = parseInt(hex[2] + hex[2], 16) / 255;
        } else if (len === 4) {
            r = parseInt(hex[0] + hex[0], 16) / 255;
            g = parseInt(hex[1] + hex[1], 16) / 255;
            b = parseInt(hex[2] + hex[2], 16) / 255;
            a = parseInt(hex[3] + hex[3], 16) / 255;
        } else if (len === 6) {
            const num = parseInt(hex, 16);
            r = ((num >> 16) & 255) / 255;
            g = ((num >> 8) & 255) / 255;
            b = (num & 255) / 255;
        } else if (len === 8) {
            const num = parseInt(hex, 16);
            r = ((num >> 24) & 255) / 255;
            g = ((num >> 16) & 255) / 255;
            b = ((num >> 8) & 255) / 255;
            a = (num & 255) / 255;
        } else {
            return [0, 0, 0, 1];
        }

        return [r, g, b, a];
    }

    _parseRgb(content) {
        const parts = content.split(',').map(s => s.trim());
        if (parts.length < 3) return [0, 0, 0, 1];

        const r = this._parseComponent(parts[0]);
        const g = this._parseComponent(parts[1]);
        const b = this._parseComponent(parts[2]);
        const a = parts[3] !== undefined ? parseFloat(parts[3]) : 1;

        return [r, g, b, isNaN(a) ? 1 : a];
    }

    _parseHsl(content) {
        const parts = content.split(',').map(s => s.trim());
        if (parts.length < 3) return [0, 0, 0, 1];

        const h = parseFloat(parts[0]);
        const s = parseFloat(parts[1]) / 100;
        const l = parseFloat(parts[2]) / 100;
        const a = parts[3] !== undefined ? parseFloat(parts[3]) : 1;

        const [r, g, b] = this._hslToRgb(h, s, l);
        return [r, g, b, isNaN(a) ? 1 : a];
    }

    _parseComponent(value) {
        if (value.includes('%')) {
            return Math.max(0, Math.min(1, parseFloat(value) / 100));
        }
        const v = parseFloat(value);
        if (v <= 1 && value.includes('.')) return Math.max(0, Math.min(1, v));
        return Math.max(0, Math.min(1, v / 255));
    }

    _hslToRgb(h, s, l) {
        if (s === 0) return [l, l, l];
        h = ((h % 360) + 360) % 360;
        const c = (1 - Math.abs(2 * l - 1)) * s;
        const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
        const m = l - c / 2;
        let r, g, b;

        if (h < 60) [r, g, b] = [c, x, 0];
        else if (h < 120) [r, g, b] = [x, c, 0];
        else if (h < 180) [r, g, b] = [0, c, x];
        else if (h < 240) [r, g, b] = [0, x, c];
        else if (h < 300) [r, g, b] = [x, 0, c];
        else [r, g, b] = [c, 0, x];

        return [r + m, g + m, b + m];
    }

    clear() {
        this._cache.clear();
    }
}

export default ColorParser;
