/**
 * BatchRenderer - Batches draw calls to minimize GPU state changes.
 * Uses separate shader programs for each mode for maximum compatibility.
 * Now supports stencil-based clipping and pattern fills.
 */

const VF = 8; // vertex floats: x,y,u,v,r,g,b,a
const VB = VF * 4; // bytes per vertex
const MAX_V = 65536;

class BatchRenderer {
    constructor(gl) {
        this.gl = gl;
        this._initSolidProg();
        this._initTexProg();
        this._initGradProg();
        this._initPatternProg();
        this._initBuffers();
        this._reset();
    }

    // ---- Solid color program ----
    _initSolidProg() {
        const gl = this.gl;
        const vs = `attribute vec2 a_pos; attribute vec4 a_color;
            uniform mat3 u_mtx; uniform vec2 u_res;
            varying vec4 v_c;
            void main(){ vec2 p=(u_mtx*vec3(a_pos,1.0)).xy;
            vec2 c=(p/u_res)*2.0-1.0; c.y=-c.y;
            gl_Position=vec4(c,0.0,1.0); v_c=a_color; }`;
        const fs = `precision mediump float; varying vec4 v_c;
            void main(){ gl_FragColor=v_c; }`;
        this.solidProg = this._compile(vs, fs);
        this.s_pos = gl.getAttribLocation(this.solidProg, 'a_pos');
        this.s_col = gl.getAttribLocation(this.solidProg, 'a_color');
        this.s_mtx = gl.getUniformLocation(this.solidProg, 'u_mtx');
        this.s_res = gl.getUniformLocation(this.solidProg, 'u_res');
    }

    // ---- Texture program ----
    _initTexProg() {
        const gl = this.gl;
        const vs = `attribute vec2 a_pos; attribute vec2 a_uv; attribute vec4 a_color;
            uniform mat3 u_mtx; uniform vec2 u_res;
            varying vec2 v_uv; varying vec4 v_c;
            void main(){ vec2 p=(u_mtx*vec3(a_pos,1.0)).xy;
            vec2 c=(p/u_res)*2.0-1.0; c.y=-c.y;
            gl_Position=vec4(c,0.0,1.0); v_uv=a_uv; v_c=a_color; }`;
        const fs = `precision mediump float; varying vec2 v_uv; varying vec4 v_c;
            uniform sampler2D u_tex;
            void main(){ gl_FragColor=texture2D(u_tex,v_uv)*v_c; }`;
        this.texProg = this._compile(vs, fs);
        this.t_pos = gl.getAttribLocation(this.texProg, 'a_pos');
        this.t_uv = gl.getAttribLocation(this.texProg, 'a_uv');
        this.t_col = gl.getAttribLocation(this.texProg, 'a_color');
        this.t_mtx = gl.getUniformLocation(this.texProg, 'u_mtx');
        this.t_res = gl.getUniformLocation(this.texProg, 'u_res');
        this.t_tex = gl.getUniformLocation(this.texProg, 'u_tex');
    }

    // ---- Gradient program ----
    _initGradProg() {
        const gl = this.gl;
        const vs = `attribute vec2 a_pos;
            uniform mat3 u_mtx; uniform vec2 u_res;
            void main(){ vec2 p=(u_mtx*vec3(a_pos,1.0)).xy;
            vec2 c=(p/u_res)*2.0-1.0; c.y=-c.y;
            gl_Position=vec4(c,0.0,1.0); }`;
        const fs = `precision mediump float;
            uniform sampler2D u_tex; uniform float u_al; uniform float u_gtype;
            uniform vec4 u_gp1; uniform vec2 u_gp2; uniform float u_gp3;
            uniform vec2 u_pix_res;
            #define PI 3.14159265
            #define TAU 6.28318530
            void main(){
                vec2 coord = vec2(gl_FragCoord.x, u_pix_res.y - gl_FragCoord.y);
                float t=0.0; vec4 col;
                if(u_gtype<1.5){
                    vec2 s=u_gp1.xy,e=u_gp1.zw,dv=e-s;
                    float dl=length(dv);
                    if(dl>0.001) t=dot(coord-s,dv/dl)/dl;
                }else if(u_gtype<2.5){
                    float d=distance(coord,u_gp1.xy);
                    float rd=u_gp1.w-u_gp1.z;
                    if(abs(rd)>0.001) t=(d-u_gp1.z)/rd; else t=step(u_gp1.z,d);
                }else{
                    vec2 dir=coord-u_gp2;
                    float a=atan(dir.y,dir.x);
                    a=mod(a-u_gp3+TAU,TAU); t=a/TAU;
                }
                t=clamp(t,0.0,1.0);
                col=texture2D(u_tex,vec2(t,0.5));
                gl_FragColor=vec4(col.rgb,col.a*u_al);
            }`;
        this.gradProg = this._compile(vs, fs);
        this.g_pos = gl.getAttribLocation(this.gradProg, 'a_pos');
        this.g_mtx = gl.getUniformLocation(this.gradProg, 'u_mtx');
        this.g_res = gl.getUniformLocation(this.gradProg, 'u_res');
        this.g_tex = gl.getUniformLocation(this.gradProg, 'u_tex');
        this.g_al = gl.getUniformLocation(this.gradProg, 'u_al');
        this.g_type = gl.getUniformLocation(this.gradProg, 'u_gtype');
        this.g_gp1 = gl.getUniformLocation(this.gradProg, 'u_gp1');
        this.g_gp2 = gl.getUniformLocation(this.gradProg, 'u_gp2');
        this.g_gp3 = gl.getUniformLocation(this.gradProg, 'u_gp3');
        this.g_pix_res = gl.getUniformLocation(this.gradProg, 'u_pix_res');
    }

    // ---- Pattern program ----
    _initPatternProg() {
        const gl = this.gl;
        const vs = `attribute vec2 a_pos; attribute vec2 a_uv;
            uniform mat3 u_mtx; uniform vec2 u_res;
            varying vec2 v_uv;
            void main(){ vec2 p=(u_mtx*vec3(a_pos,1.0)).xy;
            vec2 c=(p/u_res)*2.0-1.0; c.y=-c.y;
            gl_Position=vec4(c,0.0,1.0); v_uv=a_uv; }`;
        const fs = `precision mediump float;
            varying vec2 v_uv;
            uniform sampler2D u_tex;
            uniform float u_al;
            void main(){ vec4 c=texture2D(u_tex,v_uv); gl_FragColor=vec4(c.rgb,c.a*u_al); }`;
        this.patternProg = this._compile(vs, fs);
        this.p_pos = gl.getAttribLocation(this.patternProg, 'a_pos');
        this.p_uv = gl.getAttribLocation(this.patternProg, 'a_uv');
        this.p_mtx = gl.getUniformLocation(this.patternProg, 'u_mtx');
        this.p_res = gl.getUniformLocation(this.patternProg, 'u_res');
        this.p_tex = gl.getUniformLocation(this.patternProg, 'u_tex');
        this.p_al = gl.getUniformLocation(this.patternProg, 'u_al');
    }

    _compile(vs, fs) {
        const gl = this.gl;
        const v = gl.createShader(gl.VERTEX_SHADER);
        gl.shaderSource(v, vs); gl.compileShader(v);
        const f = gl.createShader(gl.FRAGMENT_SHADER);
        gl.shaderSource(f, fs); gl.compileShader(f);
        const p = gl.createProgram();
        gl.attachShader(p, v); gl.attachShader(p, f); gl.linkProgram(p);
        gl.deleteShader(v); gl.deleteShader(f);
        return p;
    }

    _initBuffers() {
        const gl = this.gl;
        this.vbo = gl.createBuffer();
        this.vd = new Float32Array(MAX_V * VF);
        this.vc = 0;
        const idx = new Uint16Array(MAX_V);
        for (let i = 0; i < MAX_V; i++) idx[i] = i;
        this.ibo = gl.createBuffer();
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo);
        gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, idx, gl.STATIC_DRAW);
    }

    _reset() {
        this.vc = 0;
        this.mode = 0; // 0=solid, 1=tex, 2=grad, 3=pattern
        this.gradType = 0;
        this.texture = null;
        this.mtx = new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]);
        this.alpha = 1;
        this.gp1 = [0, 0, 0, 0];
        this.gp2 = [0, 0];
        this.gp3 = 0;
        this.res = [1, 1];
        this.pixRes = [1, 1];
        this.dpr = 1;
        this._stencilEnabled = false;
        this._stencilRef = 0;
        this._blendMode = 'source-over';
    }

    setResolution(w, h) { this.res[0] = w; this.res[1] = h; this.pixRes[0] = w * this.dpr; this.pixRes[1] = h * this.dpr; }
    setDPR(dpr) { this.dpr = dpr; this.pixRes[0] = this.res[0] * dpr; this.pixRes[1] = this.res[1] * dpr; }

    /**
     * Enable/disable stencil testing for clipping.
     */
    setStencilTest(enabled, ref) {
        if (this._stencilEnabled !== enabled || (enabled && this._stencilRef !== ref)) {
            if (this.vc > 0) this._flush();
        }
        this._stencilEnabled = enabled;
        this._stencilRef = ref;
    }

    /**
     * Set blend mode for compositing operations.
     */
    setBlendMode(mode) {
        if (this._blendMode !== mode) {
            if (this.vc > 0) this._flush();
            this._blendMode = mode;
        }
    }

    _applyBlendMode() {
        const gl = this.gl;
        const mode = this._blendMode;
        // Canvas 2D composite operations mapped to WebGL blend funcs
        switch (mode) {
            case 'source-over':
            default:
                gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
                break;
            case 'source-in':
                gl.blendFunc(gl.DST_ALPHA, gl.ZERO);
                break;
            case 'source-out':
                gl.blendFunc(gl.ONE_MINUS_DST_ALPHA, gl.ZERO);
                break;
            case 'source-atop':
                gl.blendFunc(gl.DST_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
                break;
            case 'destination-over':
                gl.blendFunc(gl.ONE_MINUS_DST_ALPHA, gl.ONE);
                break;
            case 'destination-in':
                gl.blendFunc(gl.ZERO, gl.SRC_ALPHA);
                break;
            case 'destination-out':
                gl.blendFunc(gl.ZERO, gl.ONE_MINUS_SRC_ALPHA);
                break;
            case 'destination-atop':
                gl.blendFunc(gl.ONE_MINUS_DST_ALPHA, gl.SRC_ALPHA);
                break;
            case 'lighter':
            case 'add':
                gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
                break;
            case 'copy':
                gl.blendFunc(gl.ONE, gl.ZERO);
                break;
            case 'xor':
                gl.blendFunc(gl.ONE_MINUS_DST_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
                break;
            // Advanced modes require blend equations not available in WebGL1
            case 'multiply':
            case 'screen':
            case 'overlay':
            case 'darken':
            case 'lighten':
            case 'color-dodge':
            case 'color-burn':
            case 'hard-light':
            case 'soft-light':
            case 'difference':
            case 'exclusion':
            case 'hue':
            case 'saturation':
            case 'color':
            case 'luminosity':
                // Fallback to source-over for advanced modes in WebGL1
                gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
                break;
        }
    }

    _space(n) { if (this.vc + n > MAX_V) this._flush(); }

    _needFlush(mode, tex, mtx) {
        if (this.vc === 0) return false;
        if (this.mode !== mode) return true;
        if ((mode === 1 || mode === 3) && this.texture !== tex) return true;
        if (mtx) for (let i = 0; i < 9; i++) if (Math.abs(this.mtx[i] - mtx[i]) > 1e-6) return true;
        return false;
    }

    _v(x, y, u, v, r, g, b, a) {
        const d = this.vd, i = this.vc * VF;
        d[i] = x; d[i + 1] = y; d[i + 2] = u; d[i + 3] = v;
        d[i + 4] = r; d[i + 5] = g; d[i + 6] = b; d[i + 7] = a;
        this.vc++;
    }

    // ---- Public API ----

    drawSolidRect(x, y, w, h, r, g, b, a, matrix) {
        const m = matrix || this.mtx;
        if (this._needFlush(0, null, m)) this._flush();
        this.mode = 0; if (matrix) this.mtx.set(matrix);
        this._space(6);
        this._v(x, y, 0, 0, r, g, b, a);
        this._v(x + w, y, 0, 0, r, g, b, a);
        this._v(x, y + h, 0, 0, r, g, b, a);
        this._v(x + w, y, 0, 0, r, g, b, a);
        this._v(x + w, y + h, 0, 0, r, g, b, a);
        this._v(x, y + h, 0, 0, r, g, b, a);
    }

    drawTexturedQuad(x1, y1, x2, y2, x3, y3, x4, y4, u1, v1, u2, v2, r, g, b, a, matrix, texture) {
        const m = matrix || this.mtx;
        if (this._needFlush(1, texture, m)) this._flush();
        this.mode = 1; this.texture = texture; if (matrix) this.mtx.set(matrix);
        this._space(6);
        this._v(x1, y1, u1, v1, r, g, b, a);
        this._v(x2, y2, u2, v1, r, g, b, a);
        this._v(x3, y3, u1, v2, r, g, b, a);
        this._v(x2, y2, u2, v1, r, g, b, a);
        this._v(x4, y4, u2, v2, r, g, b, a);
        this._v(x3, y3, u1, v2, r, g, b, a);
    }

    drawSolidTriangles(verts, r, g, b, a, matrix) {
        const m = matrix || this.mtx;
        if (this._needFlush(0, null, m)) this._flush();
        this.mode = 0; if (matrix) this.mtx.set(matrix);
        const n = verts.length / 2;
        this._space(n);
        for (let i = 0; i < n; i++) this._v(verts[i * 2], verts[i * 2 + 1], 0, 0, r, g, b, a);
    }

    drawGradientTriangles(verts, gradType, texture, alpha, matrix,
                          gp1x, gp1y, gp1z, gp1w, gp2x, gp2y, gp3) {
        const m = matrix || this.mtx;
        if (this.vc > 0) this._flush();
        this.mode = 2; this.gradType = gradType;
        this.texture = texture; this.alpha = alpha;
        if (matrix) this.mtx.set(matrix);
        this.gp1[0] = gp1x; this.gp1[1] = gp1y; this.gp1[2] = gp1z; this.gp1[3] = gp1w;
        this.gp2[0] = gp2x; this.gp2[1] = gp2y; this.gp3 = gp3;
        const n = verts.length / 2;
        this._space(n);
        for (let i = 0; i < n; i++) this._v(verts[i * 2], verts[i * 2 + 1], 0, 0, 1, 1, 1, alpha);
    }

    /**
     * Draw triangles with a pattern texture.
     */
    drawPatternTriangles(verts, texture, alpha, matrix, u1, v1, u2, v2, u3, v3, pw, ph) {
        const m = matrix || this.mtx;
        if (this._needFlush(3, texture, m)) this._flush();
        this.mode = 3; this.texture = texture; if (matrix) this.mtx.set(matrix);
        this.alpha = alpha;
        this._space(3);
        this._v(verts[0], verts[1], u1, v1, 1, 1, 1, alpha);
        this._v(verts[2], verts[3], u2, v2, 1, 1, 1, alpha);
        this._v(verts[4], verts[5], u3, v3, 1, 1, 1, alpha);
    }

    /**
     * Draw a rectangle filled with a pattern texture.
     */
    drawPatternTexturedRect(x, y, w, h, texture, alpha, matrix, pw, ph) {
        const m = matrix || this.mtx;
        if (this._needFlush(3, texture, m)) this._flush();
        this.mode = 3; this.texture = texture; if (matrix) this.mtx.set(matrix);
        this.alpha = alpha;
        this._space(6);
        // UVs based on pattern repeat
        const u1 = x / pw, v1 = y / ph;
        const u2 = (x + w) / pw, v2 = (y + h) / ph;
        this._v(x, y, u1, v1, 1, 1, 1, alpha);
        this._v(x + w, y, u2, v1, 1, 1, 1, alpha);
        this._v(x, y + h, u1, v2, 1, 1, 1, alpha);
        this._v(x + w, y, u2, v1, 1, 1, 1, alpha);
        this._v(x + w, y + h, u2, v2, 1, 1, 1, alpha);
        this._v(x, y + h, u1, v2, 1, 1, 1, alpha);
    }

    _applyStencilState() {
        const gl = this.gl;
        if (this._stencilEnabled) {
            gl.enable(gl.STENCIL_TEST);
            gl.stencilFunc(gl.EQUAL, this._stencilRef, 0xFF);
            gl.stencilOp(gl.KEEP, gl.KEEP, gl.KEEP);
            gl.stencilMask(0x00);
        } else {
            gl.disable(gl.STENCIL_TEST);
        }
    }

    _flush() {
        if (this.vc === 0) return;
        const gl = this.gl, c = this.vc;

        this._applyBlendMode();
        this._applyStencilState();

        // Upload vertices
        gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo);
        gl.bufferData(gl.ARRAY_BUFFER, this.vd.subarray(0, c * VF), gl.DYNAMIC_DRAW);
        gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo);

        if (this.mode === 0) {
            gl.useProgram(this.solidProg);
            gl.enableVertexAttribArray(this.s_pos);
            gl.vertexAttribPointer(this.s_pos, 2, gl.FLOAT, false, VB, 0);
            gl.enableVertexAttribArray(this.s_col);
            gl.vertexAttribPointer(this.s_col, 4, gl.FLOAT, false, VB, 16);
            gl.uniformMatrix3fv(this.s_mtx, false, this.mtx);
            gl.uniform2f(this.s_res, this.res[0], this.res[1]);
        } else if (this.mode === 1) {
            gl.useProgram(this.texProg);
            gl.enableVertexAttribArray(this.t_pos);
            gl.vertexAttribPointer(this.t_pos, 2, gl.FLOAT, false, VB, 0);
            gl.enableVertexAttribArray(this.t_uv);
            gl.vertexAttribPointer(this.t_uv, 2, gl.FLOAT, false, VB, 8);
            gl.enableVertexAttribArray(this.t_col);
            gl.vertexAttribPointer(this.t_col, 4, gl.FLOAT, false, VB, 16);
            gl.uniformMatrix3fv(this.t_mtx, false, this.mtx);
            gl.uniform2f(this.t_res, this.res[0], this.res[1]);
            gl.activeTexture(gl.TEXTURE0);
            gl.bindTexture(gl.TEXTURE_2D, this.texture);
            gl.uniform1i(this.t_tex, 0);
        } else if (this.mode === 2) {
            gl.useProgram(this.gradProg);
            gl.enableVertexAttribArray(this.g_pos);
            gl.vertexAttribPointer(this.g_pos, 2, gl.FLOAT, false, VB, 0);
            gl.uniformMatrix3fv(this.g_mtx, false, this.mtx);
            gl.uniform2f(this.g_res, this.res[0], this.res[1]);
            gl.uniform1f(this.g_al, this.alpha);
            gl.uniform1f(this.g_type, this.gradType);
            gl.uniform4f(this.g_gp1, this.gp1[0], this.gp1[1], this.gp1[2], this.gp1[3]);
            gl.uniform2f(this.g_gp2, this.gp2[0], this.gp2[1]);
            gl.uniform1f(this.g_gp3, this.gp3);
            gl.uniform2f(this.g_pix_res, this.pixRes[0], this.pixRes[1]);
            gl.activeTexture(gl.TEXTURE0);
            gl.bindTexture(gl.TEXTURE_2D, this.texture);
            gl.uniform1i(this.g_tex, 0);
        } else if (this.mode === 3) {
            gl.useProgram(this.patternProg);
            gl.enableVertexAttribArray(this.p_pos);
            gl.vertexAttribPointer(this.p_pos, 2, gl.FLOAT, false, VB, 0);
            gl.enableVertexAttribArray(this.p_uv);
            gl.vertexAttribPointer(this.p_uv, 2, gl.FLOAT, false, VB, 8);
            gl.uniformMatrix3fv(this.p_mtx, false, this.mtx);
            gl.uniform2f(this.p_res, this.res[0], this.res[1]);
            gl.uniform1f(this.p_al, this.alpha);
            gl.activeTexture(gl.TEXTURE0);
            gl.bindTexture(gl.TEXTURE_2D, this.texture);
            gl.uniform1i(this.p_tex, 0);
        }

        gl.drawElements(gl.TRIANGLES, c, gl.UNSIGNED_SHORT, 0);
        this.vc = 0;
    }

    present() { this._flush(); }

    dispose() {
        const gl = this.gl;
        gl.deleteBuffer(this.vbo); gl.deleteBuffer(this.ibo);
        gl.deleteProgram(this.solidProg); gl.deleteProgram(this.texProg);
        gl.deleteProgram(this.gradProg); gl.deleteProgram(this.patternProg);
    }
}

export { BatchRenderer };
