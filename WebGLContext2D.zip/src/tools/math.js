/**
 * Math utilities for path generation and transformations.
 */

/** Clamp a value between min and max */
export function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
}

/** Linear interpolation */
export function lerp(a, b, t) {
    return a + (b - a) * t;
}

/** Smoothstep interpolation */
export function smoothstep(edge0, edge1, x) {
    const t = clamp((x - edge0) / (edge1 - edge0), 0, 1);
    return t * t * (3 - 2 * t);
}

/** Compute cubic Bezier point at t */
export function bezierCubic(t, p0, p1, p2, p3) {
    const mt = 1 - t;
    const mt2 = mt * mt;
    const mt3 = mt2 * mt;
    const t2 = t * t;
    const t3 = t2 * t;
    return mt3 * p0 + 3 * mt2 * t * p1 + 3 * mt * t2 * p2 + t3 * p3;
}

/** Compute quadratic Bezier point at t */
export function bezierQuadratic(t, p0, p1, p2) {
    const mt = 1 - t;
    return mt * mt * p0 + 2 * mt * t * p1 + t * t * p2;
}

/** Flatten a cubic Bezier curve into line segments */
export function flattenCubicBezier(p0x, p0y, p1x, p1y, p2x, p2y, p3x, p3y, out) {
    // Adaptive subdivision based on curvature
    const tol = 0.25; // Tolerance in pixels
    subdivideCubic(p0x, p0y, p1x, p1y, p2x, p2y, p3x, p3y, 0, out, tol);
}

function subdivideCubic(x0, y0, x1, y1, x2, y2, x3, y3, depth, out, tol) {
    if (depth > 12) return; // Max recursion depth

    // Calculate deviation from straight line
    const dx = x3 - x0;
    const dy = y3 - y0;
    const dist = Math.hypot(dx, dy);
    if (dist === 0) return;

    // Distance of control points from line
    const cross1 = Math.abs((x1 - x0) * dy - (y1 - y0) * dx);
    const cross2 = Math.abs((x2 - x0) * dy - (y2 - y0) * dx);
    const maxDev = Math.max(cross1, cross2) / dist;

    if (maxDev < tol) {
        out.push(x3, y3);
        return;
    }

    // Subdivide at t=0.5
    const mx01 = (x0 + x1) * 0.5, my01 = (y0 + y1) * 0.5;
    const mx12 = (x1 + x2) * 0.5, my12 = (y1 + y2) * 0.5;
    const mx23 = (x2 + x3) * 0.5, my23 = (y2 + y3) * 0.5;
    const mxa = (mx01 + mx12) * 0.5, mya = (my01 + my12) * 0.5;
    const mxb = (mx12 + mx23) * 0.5, myb = (my12 + my23) * 0.5;
    const mxc = (mxa + mxb) * 0.5, myc = (mya + myb) * 0.5;

    subdivideCubic(x0, y0, mx01, my01, mxa, mya, mxc, myc, depth + 1, out, tol);
    subdivideCubic(mxc, myc, mxb, myb, mx23, my23, x3, y3, depth + 1, out, tol);
}

/** Flatten a quadratic Bezier curve into line segments */
export function flattenQuadraticBezier(p0x, p0y, p1x, p1y, p2x, p2y, out) {
    const tol = 0.25;
    subdivideQuadratic(p0x, p0y, p1x, p1y, p2x, p2y, 0, out, tol);
}

function subdivideQuadratic(x0, y0, x1, y1, x2, y2, depth, out, tol) {
    if (depth > 12) return;

    const dx = x2 - x0;
    const dy = y2 - y0;
    const dist = Math.hypot(dx, dy);
    if (dist === 0) return;

    const cross = Math.abs((x1 - x0) * dy - (y1 - y0) * dx);
    const dev = cross / dist;

    if (dev < tol) {
        out.push(x2, y2);
        return;
    }

    const mx01 = (x0 + x1) * 0.5, my01 = (y0 + y1) * 0.5;
    const mx12 = (x1 + x2) * 0.5, my12 = (y1 + y2) * 0.5;
    const mxc = (mx01 + mx12) * 0.5, myc = (my01 + my12) * 0.5;

    subdivideQuadratic(x0, y0, mx01, my01, mxc, myc, depth + 1, out, tol);
    subdivideQuadratic(mxc, myc, mx12, my12, x2, y2, depth + 1, out, tol);
}

/** Flatten an elliptical arc into line segments */
export function flattenArc(cx, cy, rx, ry, startAngle, endAngle, rotation, counterclockwise, out) {
    const tau = 2 * Math.PI;
    let delta = endAngle - startAngle;

    if (counterclockwise) {
        if (delta > 0) delta -= Math.ceil(delta / tau) * tau;
        if (delta === 0) delta = -tau;
    } else {
        if (delta < 0) delta += Math.ceil(-delta / tau) * tau;
        if (delta === 0) delta = tau;
    }

    // Adaptive step count based on arc size
    const arcLen = Math.abs(delta) * Math.max(rx, ry);
    const steps = Math.max(4, Math.min(128, Math.ceil(arcLen * 0.5)));
    const step = delta / steps;

    const cosR = Math.cos(rotation);
    const sinR = Math.sin(rotation);

    for (let i = 1; i <= steps; i++) {
        const angle = startAngle + step * i;
        const pdx = Math.cos(angle) * rx;
        const pdy = Math.sin(angle) * ry;
        // Apply rotation around center (cx, cy)
        out.push(cx + pdx * cosR - pdy * sinR, cy + pdx * sinR + pdy * cosR);
    }
}

/** Convert DOMMatrix to flat 3x3 array */
export function matrixToArray(m) {
    // Use toFloat32Array if available (most reliable)
    if (m.toFloat32Array) {
        const f = m.toFloat32Array();
        return [f[0], f[1], 0, f[4], f[5], 0, f[12], f[13], 1];
    }
    if (m.toFloat64Array) {
        const f = m.toFloat64Array();
        return [f[0], f[1], 0, f[4], f[5], 0, f[12], f[13], 1];
    }
    // Fallback: try direct properties
    return [
        (m.m11 !== undefined ? m.m11 : m.a) ?? 1,
        (m.m12 !== undefined ? m.m12 : m.b) ?? 0, 0,
        (m.m21 !== undefined ? m.m21 : m.c) ?? 0,
        (m.m22 !== undefined ? m.m22 : m.d) ?? 1, 0,
        (m.m41 !== undefined ? m.m41 : m.e) ?? 0,
        (m.m42 !== undefined ? m.m42 : m.f) ?? 0, 1
    ];
}

/** Check if a point is inside a triangle */
export function pointInTriangle(px, py, x1, y1, x2, y2, x3, y3) {
    const d1 = (px - x2) * (y1 - y2) - (x1 - x2) * (py - y2);
    const d2 = (px - x3) * (y2 - y3) - (x2 - x3) * (py - y3);
    const d3 = (px - x1) * (y3 - y1) - (x3 - x1) * (py - y1);
    const hasNeg = (d1 < 0) || (d2 < 0) || (d3 < 0);
    const hasPos = (d1 > 0) || (d2 > 0) || (d3 > 0);
    return !(hasNeg && hasPos);
}
