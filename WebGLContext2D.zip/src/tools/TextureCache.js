/**
 * LRU Texture Cache for efficient image texture management.
 * Prevents duplicate texture creation and manages memory.
 */
class TextureCache {
    constructor(gl, maxSize = 256) {
        this.gl = gl;
        this.maxSize = maxSize;
        this.cache = new Map(); // key -> {texture, refCount, lastUsed}
        this.accessOrder = []; // LRU tracking
    }

    /** Get or create texture for an image source */
    get(source) {
        const key = this._key(source);
        const entry = this.cache.get(key);

        if (entry) {
            entry.refCount++;
            entry.lastUsed = performance.now();
            this._touch(key);
            return entry.texture;
        }

        // Create new texture
        const texture = this._createTexture(source);
        if (!texture) return null;

        this._evictIfNeeded();
        this.cache.set(key, {
            texture,
            refCount: 1,
            lastUsed: performance.now(),
            width: source.naturalWidth || source.width || 0,
            height: source.naturalHeight || source.height || 0
        });
        this.accessOrder.push(key);
        return texture;
    }

    /** Create a GPU texture from an image source */
    _createTexture(source) {
        const gl = this.gl;
        const texture = gl.createTexture();
        if (!texture) return null;

        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

        try {
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
            return texture;
        } catch (e) {
            gl.deleteTexture(texture);
            return null;
        }
    }

    /** Generate cache key for a source */
    _key(source) {
        if (source.src) return source.src;
        if (source._webglId) return source._webglId;
        source._webglId = '_tex_' + (TextureCache._idCounter++);
        return source._webglId;
    }

    _touch(key) {
        const idx = this.accessOrder.indexOf(key);
        if (idx >= 0) {
            this.accessOrder.splice(idx, 1);
            this.accessOrder.push(key);
        }
    }

    _evictIfNeeded() {
        while (this.cache.size >= this.maxSize && this.accessOrder.length > 0) {
            const oldest = this.accessOrder.shift();
            const entry = this.cache.get(oldest);
            if (entry && entry.refCount <= 0) {
                this.gl.deleteTexture(entry.texture);
                this.cache.delete(oldest);
            }
        }
    }

    /** Release a texture reference */
    release(source) {
        const key = this._key(source);
        const entry = this.cache.get(key);
        if (entry) {
            entry.refCount = Math.max(0, entry.refCount - 1);
        }
    }

    /** Create a texture from raw pixel data (for gradients) */
    createFromData(width, height, data) {
        const gl = this.gl;
        const texture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, data);
        return texture;
    }

    /** Clear all cached textures */
    clear() {
        for (const entry of this.cache.values()) {
            this.gl.deleteTexture(entry.texture);
        }
        this.cache.clear();
        this.accessOrder = [];
    }

    /** Dispose the cache */
    dispose() {
        this.clear();
    }
}

TextureCache._idCounter = 0;

export default TextureCache;
