/**
 * WebGLContext2D - High-performance Canvas 2D API implementation via WebGL.
 *
 * Features:
 * - Batch rendering for minimal GPU draw calls
 * - Full Canvas 2D API compatibility
 * - Hardware-accelerated gradients, images, and text
 * - Stencil-based clipping with nesting (nonzero/evenodd fill rules)
 * - Optimized for 60fps with thousands of objects
 * - Zero external dependencies
 *
 * @version 3.0.0
 * @license MIT
 */

import { BatchRenderer } from './tools/BatchRenderer.js';
import TextureCache      from './tools/TextureCache.js';
import GlyphAtlas        from './tools/GlyphAtlas.js';
import ColorParser       from './tools/ColorParser.js';
import { StateStack }    from './api/state.js';
import { PathBuilder }   from './api/path.js';
import { WebGLLinearGradient, WebGLRadialGradient, WebGLConicGradient, WebGLPattern } from './api/gradient.js';
import {
    triangulateContours,
    drawTriangles,
    fillRect   as drawFillRect,
    strokeRect as drawStrokeRect,
    clearRect  as drawClearRect,
    getStrokeVertices
} from './api/drawing.js';
import {
    drawImage,
    createImageData as apiCreateImageData,
    getImageData    as apiGetImageData,
    putImageData    as apiPutImageData
} from './api/image.js';
import { fillText, measureText } from './api/text.js';
import {
    initClipState,
    restoreClip,
    resetClip,
    clip as doClip
} from './api/clip.js';
import { matrixToArray } from './tools/math.js';
import { Path2D } from './api/Path2D.js';

export { WebGLLinearGradient, WebGLRadialGradient, WebGLConicGradient, WebGLPattern, Path2D };

class WebGLContext2D {

    constructor(canvas, opts = {}) {
        if (!canvas || canvas.nodeName !== 'CANVAS') {
            throw new TypeError('Argument 1 must be a canvas element');
        }

        this._canvas = canvas;
        this._opts = {
            alpha: true,
            stencil: true,
            antialias: false,
            depth: false,
            preserveDrawingBuffer: true,
            ...opts
        };

        const gl = canvas.getContext('webgl2', this._opts)
            || canvas.getContext('webgl', this._opts);
        if (!gl) throw new Error('WebGL not supported');
        this.gl = gl;

        this._dpr = opts.pixelRatio > 0 ? opts.pixelRatio : 1;

        this._colorParser = new ColorParser();
        this._renderer = new BatchRenderer(gl);
        this._renderer.setDPR(this._dpr);
        this._textureCache = new TextureCache(gl);
        this._glyphAtlas = new GlyphAtlas(gl);
        this.state = new StateStack();
        this._path = new PathBuilder();
        initClipState(this);

        this._setupGL();
        this._resize();

        // Auto-present: flush at end of microtask if drawing occurred
        this._needsPresent = false;
        this._presentScheduled = false;
    }

    _setupGL() {
        const gl = this.gl;
        gl.enable(gl.BLEND);
        gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
        gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    }

    /** Schedule auto-present if not already scheduled */
    _schedulePresent() {
        this._needsPresent = true;
        if (!this._presentScheduled) {
            this._presentScheduled = true;
            queueMicrotask(() => {
                this._presentScheduled = false;
                if (this._needsPresent) {
                    this._needsPresent = false;
                    this.present();
                }
            });
        }
    }

    /** Check if canvas size changed and update viewport/resolution */
    _checkResize() {
        const gl = this.gl;
        const w = gl.canvas.width || 300;
        const h = gl.canvas.height || 150;
        if (w !== this._lastW || h !== this._lastH) {
            this._lastW = w;
            this._lastH = h;
            this._renderer.setResolution(w, h);
            gl.viewport(0, 0, w, h);
        }
    }

    get canvas() { return this._canvas; }

    getContextAttributes() {
        return { alpha: this._opts.alpha, colorSpace: 'srgb', desynchronized: false, willReadFrequently: false };
    }

    // ---- State ----
    save() {
        this.state.current.clipDepth = this._clipDepth;
        this.state.save();
    }

    restore() {
        const savedDepth = this.state.stack.length > 0
            ? this.state.stack[this.state.stack.length - 1].clipDepth
            : 0;
        this.state.restore();
        restoreClip(this, savedDepth);
    }

    reset() {
        this._renderer.present();
        this.state.reset();
        resetClip(this);
        this._path.reset();
        this._setupGL();
    }

    // ---- Clear (Canvas 2D compatible) ----
    clear() {
        const gl = this.gl;
        this._renderer.present();
        gl.clearColor(0, 0, 0, 0);
        gl.clear(gl.COLOR_BUFFER_BIT | gl.STENCIL_BUFFER_BIT);
    }

    // ---- Transform ----
    scale(x, y) { this.state.scale(x, y); }
    translate(x, y) { this.state.translate(x, y); }
    rotate(angle) { this.state.rotate(angle); }
    setTransform(a, b, c, d, e, f) { this.state.setTransform(...arguments); }
    resetTransform() { this.state.resetTransform(); }
    transform(a, b, c, d, e, f) { this.state.transform(a, b, c, d, e, f); }
    getTransform() { return this.state.getTransform(); }

    // ---- Style Properties ----
    get globalAlpha() { return this.state.globalAlpha; }
    set globalAlpha(v) { this.state.globalAlpha = v; }
    get fillStyle() { return this.state.fillStyle; }
    set fillStyle(v) { this.state.fillStyle = v; }
    get strokeStyle() { return this.state.strokeStyle; }
    set strokeStyle(v) { this.state.strokeStyle = v; }
    get lineWidth() { return this.state.lineWidth; }
    set lineWidth(v) { this.state.lineWidth = v; }
    get lineCap() { return this.state.lineCap; }
    set lineCap(v) { this.state.lineCap = v; }
    get lineJoin() { return this.state.lineJoin; }
    set lineJoin(v) { this.state.lineJoin = v; }
    get miterLimit() { return this.state.miterLimit; }
    set miterLimit(v) { this.state.miterLimit = v; }
    get lineDashOffset() { return this.state.lineDashOffset; }
    set lineDashOffset(v) { this.state.lineDashOffset = v; }
    get shadowBlur() { return this.state.shadowBlur; }
    set shadowBlur(v) { this.state.shadowBlur = v; }
    get shadowColor() { return this.state.shadowColor; }
    set shadowColor(v) { this.state.shadowColor = v; }
    get shadowOffsetX() { return this.state.shadowOffsetX; }
    set shadowOffsetX(v) { this.state.shadowOffsetX = v; }
    get shadowOffsetY() { return this.state.shadowOffsetY; }
    set shadowOffsetY(v) { this.state.shadowOffsetY = v; }
    get globalCompositeOperation() { return this.state.globalCompositeOperation; }
    set globalCompositeOperation(v) { this.state.globalCompositeOperation = v; }
    get imageSmoothingEnabled() { return this.state.imageSmoothingEnabled; }
    set imageSmoothingEnabled(v) { this.state.imageSmoothingEnabled = v; }
    get imageSmoothingQuality() { return this.state.imageSmoothingQuality; }
    set imageSmoothingQuality(v) { this.state.imageSmoothingQuality = v; }
    get filter() { return this.state.filter; }
    set filter(v) { this.state.filter = v; }
    get font() { return this.state.font; }
    set font(v) { this.state.font = v; }
    get textAlign() { return this.state.textAlign; }
    set textAlign(v) { this.state.textAlign = v; }
    get textBaseline() { return this.state.textBaseline; }
    set textBaseline(v) { this.state.textBaseline = v; }
    get direction() { return this.state.direction; }
    set direction(v) { this.state.direction = v; }
    get letterSpacing() { return this.state.letterSpacing; }
    set letterSpacing(v) { this.state.letterSpacing = v; }
    get wordSpacing() { return this.state.wordSpacing; }
    set wordSpacing(v) { this.state.wordSpacing = v; }
    get textRendering() { return this.state.textRendering; }
    set textRendering(v) { this.state.textRendering = v; }
    get fontKerning() { return this.state.fontKerning; }
    set fontKerning(v) { this.state.fontKerning = v; }
    get fontStretch() { return this.state.fontStretch; }
    set fontStretch(v) { this.state.fontStretch = v; }
    get fontVariantCaps() { return this.state.fontVariantCaps; }
    set fontVariantCaps(v) { this.state.fontVariantCaps = v; }
    get lang() { return this.state.lang; }
    set lang(v) { this.state.lang = v; }

    // ---- Path ----
    beginPath() { this._path.reset(); }
    closePath() { this._path.closePath(); }
    moveTo(x, y) { this._path.moveTo(x, y); }
    lineTo(x, y) { this._path.lineTo(x, y); }
    quadraticCurveTo(cpx, cpy, x, y) { this._path.quadraticCurveTo(cpx, cpy, x, y); }
    bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y) { this._path.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x, y); }
    arc(x, y, radius, startAngle, endAngle, counterclockwise = false) {
        this._path.arc(x, y, radius, startAngle, endAngle, counterclockwise);
    }
    arcTo(x1, y1, x2, y2, radius) { this._path.arcTo(x1, y1, x2, y2, radius); }
    ellipse(x, y, rx, ry, rotation, startAngle, endAngle, counterclockwise = false) {
        this._path.ellipse(x, y, rx, ry, rotation, startAngle, endAngle, counterclockwise);
    }
    rect(x, y, w, h) { this._path.rect(x, y, w, h); }
    roundRect(x, y, w, h, radii) { this._path.roundRect(x, y, w, h, radii); }

    // ---- Internal: sync composite operation ----
    _syncBlendMode() {
        this._renderer.setBlendMode(this.state.globalCompositeOperation);
    }

    // ---- Context State ----
    isContextLost() {
        const gl = this.gl;
        return gl.isContextLost ? gl.isContextLost() : false;
    }

    drawFocusIfNeeded(element) {
        // Canvas 2D spec: if element is focused, draw a focus ring around current path
        // This is a no-op in WebGL since we don't have native focus ring rendering
        if (element && document.activeElement === element) {
            // A focused element would draw a focus ring - minimal implementation
            // Applications should handle focus visualization themselves
        }
    }

    // ---- Drawing ----
    fill(fillRuleOrPath, fillRule) {
        this._syncBlendMode();
        let rule = 'nonzero';
        let path = this._path;

        if (fillRuleOrPath instanceof Path2D) {
            path = fillRuleOrPath._pathBuilder || fillRuleOrPath;
            if (typeof fillRule === 'string') rule = fillRule;
        } else if (typeof fillRuleOrPath === 'string') {
            rule = fillRuleOrPath;
        }

        const contours = path.getContours();
        if (contours.length === 0) return;
        const triangles = triangulateContours(contours);
        if (triangles.length === 0) return;

        // Shadow pass - draw offset shadow triangles with blur approximation
        if (this.state.shadowBlur > 0 && this.state.shadowColor !== 'transparent') {
            const sc = this._colorParser.parse(this.state.shadowColor);
            const sa = sc[3] * this.state.globalAlpha;
            const ox = this.state.shadowOffsetX;
            const oy = this.state.shadowOffsetY;
            const blur = this.state.shadowBlur;
            // Draw shadow with expanded bounds for blur effect
            const shadowVerts = [];
            for (let i = 0; i < triangles.length; i += 2) {
                shadowVerts.push(triangles[i] + ox, triangles[i + 1] + oy);
            }
            this._renderer.setStencilTest(this._clipDepth > 0, this._clipDepth);
            // Draw shadow multiple times with slight offsets for blur approximation
            const steps = Math.min(8, Math.max(1, Math.ceil(blur / 3)));
            for (let s = 0; s < steps; s++) {
                const f = s / steps;
                const a = sa * (1 - f * 0.7);
                this._renderer.drawSolidTriangles(shadowVerts, sc[0], sc[1], sc[2], a, this._getMatrix());
            }
        }

        this._renderer.setStencilTest(this._clipDepth > 0, this._clipDepth);
        drawTriangles(this._renderer, triangles, this.state.fillStyle,
            this.state.globalAlpha, this._getMatrix(), this._colorParser, this._dpr);
        this._renderer.setStencilTest(false, 0);
        this._schedulePresent();
    }

    stroke(path) {
        this._syncBlendMode();
        let pathBuilder = this._path;
        if (path instanceof Path2D) {
            pathBuilder = path._pathBuilder || path;
        }

        // Use getStrokeVertices which handles line dash internally
        const dash = this.state.current.lineDash;
        const strokeVerts = getStrokeVertices(pathBuilder,
            this.state.lineWidth, this.state.lineCap, this.state.lineJoin, this.state.miterLimit, dash);

        if (strokeVerts.length === 0) return;
        const color = this._colorParser.parse(this.state.strokeStyle);

        this._renderer.setStencilTest(this._clipDepth > 0, this._clipDepth);
        this._renderer.drawSolidTriangles(strokeVerts,
            color[0], color[1], color[2], color[3] * this.state.globalAlpha, this._getMatrix());
        this._renderer.setStencilTest(false, 0);
        this._schedulePresent();
    }

    fillRect(x, y, w, h) {
        this._syncBlendMode();
        // Shadow pass - draw offset expanded rect for blur approximation
        if (this.state.shadowBlur > 0 && this.state.shadowColor !== 'transparent') {
            const sc = this._colorParser.parse(this.state.shadowColor);
            const sa = sc[3] * this.state.globalAlpha;
            const ox = this.state.shadowOffsetX;
            const oy = this.state.shadowOffsetY;
            const blur = this.state.shadowBlur;
            const steps = Math.min(6, Math.max(1, Math.ceil(blur / 4)));
            for (let s = 0; s < steps; s++) {
                const f = s / steps;
                const a = sa * (1 - f * 0.7);
                const expand = blur * 0.5 * (1 - f);
                this._renderer.drawSolidRect(
                    x + ox - expand, y + oy - expand,
                    w + expand * 2, h + expand * 2,
                    sc[0], sc[1], sc[2], a, this._getMatrix());
            }
        }

        this._renderer.setStencilTest(this._clipDepth > 0, this._clipDepth);
        drawFillRect(this._renderer, x, y, w, h, this.state.fillStyle,
            this.state.globalAlpha, this._getMatrix(), this._colorParser, this.gl, this._dpr);
        this._renderer.setStencilTest(false, 0);
        this._schedulePresent();
    }

    strokeRect(x, y, w, h) {
        this._syncBlendMode();
        this._renderer.setStencilTest(this._clipDepth > 0, this._clipDepth);
        drawStrokeRect(this._renderer, x, y, w, h, this.state.strokeStyle,
            this.state.globalAlpha, this.state.lineWidth, this._getMatrix(), this._colorParser);
        this._renderer.setStencilTest(false, 0);
        this._schedulePresent();
    }

    clearRect(x, y, w, h) {
        drawClearRect(this.gl, this._renderer, x, y, w, h,
            this._canvas.width, this._canvas.height);
    }

    // ---- Clip ----
    clip(fillRuleOrPath, fillRule) {
        let rule = 'nonzero';
        let path = this._path;

        if (typeof fillRuleOrPath === 'string') {
            rule = fillRuleOrPath;
        } else if (fillRuleOrPath && (fillRuleOrPath instanceof Path2D || fillRuleOrPath._pathBuilder)) {
            path = fillRuleOrPath._pathBuilder || fillRuleOrPath;
            if (typeof fillRule === 'string') rule = fillRule;
        } else if (fillRuleOrPath && typeof fillRuleOrPath === 'object' && typeof fillRuleOrPath.getContours === 'function') {
            path = fillRuleOrPath;
            if (typeof fillRule === 'string') rule = fillRule;
        }

        doClip(this, path, rule);
        this._schedulePresent();
    }

    // ---- Image ----
    drawImage(image, ...args) {
        this._syncBlendMode();
        if (!image) throw new TypeError('drawImage requires an image');
        this._renderer.setStencilTest(this._clipDepth > 0, this._clipDepth);
        drawImage(this._renderer, this._textureCache, image, args,
            this.state.globalAlpha, this.state._transform,
            this._canvas.width, this._canvas.height);
        this._renderer.setStencilTest(false, 0);
        this._schedulePresent();
    }

    createImageData(sw, sh, settings) {
        return apiCreateImageData(sw, sh, settings);
    }

    getImageData(sx, sy, sw, sh, settings) {
        this._renderer.present();
        return apiGetImageData(this.gl, sx, sy, sw, sh);
    }

    putImageData(imageData, dx, dy, dirtyX, dirtyY, dirtyWidth, dirtyHeight) {
        apiPutImageData(this.gl, this._renderer, imageData, dx, dy,
            dirtyX, dirtyY, dirtyWidth, dirtyHeight);
    }

    // ---- Text ----
    fillText(text, x, y, maxWidth) {
        this._syncBlendMode();
        this._renderer.setStencilTest(this._clipDepth > 0, this._clipDepth);
        fillText(this._renderer, this._glyphAtlas, text, x, y, maxWidth,
            this.state.font, this.state.textAlign, this.state.textBaseline,
            this.state.direction, this.state.fillStyle, this.state.globalAlpha,
            this.state._transform, this.state.letterSpacing);
        this._renderer.setStencilTest(false, 0);
        this._schedulePresent();
    }

    strokeText(text, x, y, maxWidth) {
        const oldFill = this.state.fillStyle;
        this.state.fillStyle = this.state.strokeStyle;
        this.fillText(text, x, y, maxWidth);
        this.state.fillStyle = oldFill;
    }

    measureText(text) {
        return measureText(text, this.state.font);
    }

    // ---- Gradient ----
    createLinearGradient(x0, y0, x1, y1) {
        return new WebGLLinearGradient(Number(x0) || 0, Number(y0) || 0, Number(x1) || 0, Number(y1) || 0);
    }
    createRadialGradient(x0, y0, r0, x1, y1, r1) {
        return new WebGLRadialGradient(Number(x0) || 0, Number(y0) || 0, Number(r0) || 0,
            Number(x1) || 0, Number(y1) || 0, Number(r1) || 0);
    }
    createConicGradient(angle, x, y) {
        return new WebGLConicGradient(Number(angle) || 0, Number(x) || 0, Number(y) || 0);
    }
    createPattern(image, repetition) {
        return new WebGLPattern(image, repetition);
    }

    // ---- Line Dash ----
    getLineDash() {
        return Array.from(this.state.current.lineDash || []);
    }
    setLineDash(segments) {
        if (!Array.isArray(segments)) throw new TypeError('setLineDash argument must be an array');
        const valid = segments.map(s => { const v = Number(s); return isNaN(v) ? 0 : Math.max(0, v); });
        this.state.current.lineDash = new Float64Array(valid);
    }

    // ---- Hit Testing ----
    isPointInPath(x, y, fillRule) {
        let testX, testY, rule = 'nonzero';
        let path = this._path;

        // Handle isPointInPath(path, x, y, fillRule) overload
        if (x instanceof Path2D) {
            path = x._pathBuilder || x;
            testX = y;
            testY = fillRule;
            rule = arguments[3] || 'nonzero';
            if (typeof rule !== 'string') rule = 'nonzero';
        } else if (typeof x === 'number') {
            testX = x; testY = y; rule = fillRule || 'nonzero';
        } else {
            return false;
        }

        const contours = path.getContours();
        const triangles = triangulateContours(contours);
        const m = this.state._transform;
        const det = m.a * m.d - m.b * m.c;
        if (Math.abs(det) < 1e-10) return false;
        const invA = m.d / det, invB = -m.b / det, invC = -m.c / det;
        const invD = m.a / det, invE = (m.c * m.f - m.d * m.e) / det, invF = (m.b * m.e - m.a * m.f) / det;
        const px = testX * invA + testY * invC + invE;
        const py = testX * invB + testY * invD + invF;

        // Use evenodd rule if specified
        if (rule === 'evenodd') {
            // Ray casting for evenodd rule
            let crossings = 0;
            for (const contour of contours) {
                const len = contour.length / 2;
                for (let i = 0; i < len; i++) {
                    const x1 = contour[i * 2], y1 = contour[i * 2 + 1];
                    const x2 = contour[((i + 1) % len) * 2], y2 = contour[((i + 1) % len) * 2 + 1];
                    if (((y1 > py) !== (y2 > py)) && (px < (x2 - x1) * (py - y1) / (y2 - y1) + x1)) {
                        crossings++;
                    }
                }
            }
            return crossings % 2 !== 0;
        }

        // Nonzero: check if point is inside any triangle
        for (let i = 0; i < triangles.length; i += 6) {
            const x1 = triangles[i], y1 = triangles[i + 1];
            const x2 = triangles[i + 2], y2 = triangles[i + 3];
            const x3 = triangles[i + 4], y3 = triangles[i + 5];
            const d1 = (px - x2) * (y1 - y2) - (x1 - x2) * (py - y2);
            const d2 = (px - x3) * (y2 - y3) - (x2 - x3) * (py - y3);
            const d3 = (px - x1) * (y3 - y1) - (x3 - x1) * (py - y1);
            const hasNeg = (d1 < 0) || (d2 < 0) || (d3 < 0);
            const hasPos = (d1 > 0) || (d2 > 0) || (d3 > 0);
            if (!(hasNeg && hasPos)) return true;
        }
        return false;
    }

    isPointInStroke(x, y) {
        let testX, testY;
        let path = this._path;

        // Handle isPointInStroke(path, x, y) overload
        if (x instanceof Path2D) {
            path = x._pathBuilder || x;
            testX = y;
            testY = arguments[2];
        } else if (typeof x === 'number') {
            testX = x; testY = y;
        } else {
            return false;
        }

        // Get stroke vertices and check if point is near any stroke segment
        const strokeVerts = path.getStrokeVertices(
            this.state.lineWidth, this.state.lineCap, this.state.lineJoin, this.state.miterLimit);
        const m = this.state._transform;
        const det = m.a * m.d - m.b * m.c;
        if (Math.abs(det) < 1e-10) return false;
        const invA = m.d / det, invB = -m.b / det, invC = -m.c / det;
        const invD = m.a / det, invE = (m.c * m.f - m.d * m.e) / det, invF = (m.b * m.e - m.a * m.f) / det;
        const px = testX * invA + testY * invC + invE;
        const py = testX * invB + testY * invD + invF;

        // Each stroke is a quad (6 vertices = 2 triangles)
        const hw = this.state.lineWidth / 2;
        const threshold = hw + 1; // tolerance

        for (let i = 0; i < strokeVerts.length; i += 12) {
            // Check bounding box of stroke segment
            let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
            for (let j = 0; j < 12 && i + j < strokeVerts.length; j += 2) {
                minX = Math.min(minX, strokeVerts[i + j]);
                maxX = Math.max(maxX, strokeVerts[i + j]);
                minY = Math.min(minY, strokeVerts[i + j + 1]);
                maxY = Math.max(maxY, strokeVerts[i + j + 1]);
            }
            if (px >= minX - threshold && px <= maxX + threshold &&
                py >= minY - threshold && py <= maxY + threshold) {
                return true;
            }
        }
        return false;
    }

    // ---- Internal ----
    _getMatrix() {
        return matrixToArray(this.state._transform);
    }

    _resize() {
        const w = this._canvas.width || 300;
        const h = this._canvas.height || 150;

        if (this._opts.pixelRatio > 0) {
            const cssW = w;
            const cssH = h;
            const pixW = Math.floor(cssW * this._dpr);
            const pixH = Math.floor(cssH * this._dpr);
            if (this._canvas.width !== pixW || this._canvas.height !== pixH) {
                this._canvas.width = pixW;
                this._canvas.height = pixH;
            }
        }

        this._lastW = this._canvas.width;
        this._lastH = this._canvas.height;
        this._renderer.setResolution(this._canvas.width, this._canvas.height);
        this.gl.viewport(0, 0, this._canvas.width, this._canvas.height);
    }

    present() {
        this._needsPresent = false;
        this._checkResize();
        this._renderer.present();
    }

    dispose() {
        this._renderer.dispose();
        this._textureCache.dispose();
        this._glyphAtlas.dispose();
        if (this._clipProgram) this.gl.deleteProgram(this._clipProgram);
        if (this._clipBuf) this.gl.deleteBuffer(this._clipBuf);
    }
}

// ===================== CANVAS PATCH =====================
if (typeof HTMLCanvasElement !== 'undefined') {
    const orig = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function (type, attrs) {
        if (type === 'webgl-2d') {
            if (!this._webgl2dCtx) this._webgl2dCtx = new WebGLContext2D(this, attrs);
            return this._webgl2dCtx;
        }
        return orig.call(this, type, attrs);
    };
}

export default WebGLContext2D;